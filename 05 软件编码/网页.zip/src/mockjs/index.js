// import Vue from 'vue'
import Mock from 'mockjs'
// process.env.NODE_ENV === "development" ? Vue.use(Mock) : null;

import tableAPI from './usermanger'
import salesAPI from './sales'
import userAPI from './user'
import messageAPI from './message'
import applyAPI from './apply'
// 设置全局延时 没有延时的话有时候会检测不到数据变化 建议保留
Mock.setup({
    timeout: '300-600'
})
// 用户相关
Mock.mock(/\/message\/get/, 'get', messageAPI.getMoneyList)
Mock.mock(/\/message\/remove/, 'get', messageAPI.deleteMoney)
Mock.mock(/\/message\/batchremove/, 'get', messageAPI.batchremoveMoney)
Mock.mock(/\/message\/add/, 'get', messageAPI.createMoney)
Mock.mock(/\/message\/edit/, 'get', messageAPI.updateMoney)
// 审批相关
Mock.mock(/\/apply\/get/, 'get', applyAPI.getMoneyList)
Mock.mock(/\/apply\/remove/, 'get', applyAPI.deleteMoney)
Mock.mock(/\/apply\/batchremove/, 'get', applyAPI.batchremoveMoney)
Mock.mock(/\/apply\/add/, 'get', applyAPI.createMoney)
Mock.mock(/\/apply\/edit/, 'get', applyAPI.updateMoney)

Mock.mock(/\/usermanger\/get/, 'get', tableAPI.getMoneyList)
Mock.mock(/\/usermanger\/remove/, 'get', tableAPI.deleteMoney)
Mock.mock(/\/usermanger\/batchremove/, 'get', tableAPI.batchremoveMoney)
Mock.mock(/\/usermanger\/add/, 'get', tableAPI.createMoney)
Mock.mock(/\/usermanger\/edit/, 'get', tableAPI.updateMoney)

Mock.mock(/\/sales\/get/, 'get', salesAPI.getSalesList)

Mock.mock(/\/user\/login/, 'get', userAPI.login)
Mock.mock(/\/user\/logout/, 'get', userAPI.logout)
Mock.mock(/\/user\/info\/get/, 'get', userAPI.getUserInfo)
Mock.mock(/\/user\/list\/get/, 'get', userAPI.getUserList)

export default Mock;