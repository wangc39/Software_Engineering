import Mock from 'mockjs'

import * as mUtils from '@/utils/mUtils'
import Bmob from '../dist/Bmob-2.2.5.min.js'

Bmob.initialize("f5548270aaba8ebe","674436")
// Vue.prototype.Bmob = Bmob
let List = []
const count = 1000
let typelist = ['联通', '移动', '电信', '铁通']
const query = Bmob.Query("Person");
query.find().then(res => {
  console.log(res[0])
  List = JSON.parse(JSON.stringify(res)); 
  List.reverse()
});

function destory(objectId){
  const query = Bmob.Query('Person');
  query.get(objectId).then(res => {
    let ccList = []
    if(res.hasOwnProperty('children')){
      ccList = JSON.parse(JSON.stringify(res.children)); 
    }

    if(res.father_name){
      const fquery = Bmob.Query("Person");
      fquery.equalTo("username", '==', res.father_name);
      fquery.equalTo("birthday", '==', res.father_bir);
      fquery.find().then(fres => {
        if(fres.length > 0){
          const ffquery = Bmob.Query('Person');
          ffquery.get(fres[0].objectId).then(ffres => {
            let cList = []
            cList = JSON.parse(JSON.stringify(ffres.children)); 
            cList = cList.filter(u => u.objectId !== objectId)
            ffres.set('children', cList)
            ffres.save()
          }).catch(err => {
            console.log(err)
          })
        }
        console.log(fres)
      });
    }
    if(res.level == 0){
      const branquery = Bmob.Query("Branch");
      branquery.equalTo("personid","==", objectId);
      branquery.find().then(branres => {
        const desquery = Bmob.Query('Branch');
        desquery.destroy(branres[0].objectId).then(desres => {
          console.log(desres)
        }).catch(err => {
          console.log(err)
        })
      });
    }
    if(res.wife){
      const query = Bmob.Query('Person');
      query.destroy(res.wife).then(wres => {
        console.log(wres)
      }).catch(err => {
        console.log(err)
      })
    }
    console.log(ccList)
    var i;
      for(i = 0; i < ccList.length; i ++){
        console.log(i)
        destory(ccList[i])
      }
    
  }).catch(err => {
    console.log(err)
  })
  const dquery = Bmob.Query('Person');
  dquery.destroy(objectId).then(wres => {
    console.log(wres)
  }).catch(err => {
    console.log(err)
  })
}

export default {
  /**
   * 获取列表
   * 要带参数 name, page, limt; name可以不填, page,limit有默认值。
   * @param name, page, limit
   * @return {{code: number, count: number, data: *[]}}
   */
  getMoneyList: config => {
    const query = Bmob.Query("Person");
    query.find().then(res => {
      console.log(res[0])
      List = JSON.parse(JSON.stringify(res)); 
    });
    const { name, page = 1, limit = 20 } = mUtils.param2Obj(config.url)
    const mockList = List.filter(user => {
      if (name && user.username.indexOf(name) === -1) return false
      return true
    })
    const pageList = mockList.filter((item, index) => index < limit * page && index >= limit * (page - 1))
    return {
      code: 200,
      data: {
        total: mockList.length,
        moneyList: pageList
      }
    }
  },
  /**
   * 增加资金信息
   * @param username, address, createTime, income, pay , accoutCash, incomePayType
   * @return {{code: number, data: {message: string}}}
   */
  createMoney: config => {
    const { username, birthday, wife_name, gender} = mUtils.param2Obj(config.url)
    List.unshift({
      id: Mock.Random.guid(),
      username: username,
      wife_name: wife_name,
      gender:gender,
      birthday: birthday,

    })
    const query = Bmob.Query("Person");
    query.find().then(res => {
    console.log(res[0])
    List = JSON.parse(JSON.stringify(res)); 
    List.reverse()
    });
    return {
      code: 200,
      data: {
        message: '添加成功'
      }
    }
  },
  /**
   * 删除用户
   * @param id
   * @return {*}
   */
  deleteMoney: config => {
    const { objectId } = mUtils.param2Obj(config.url)
    if (!objectId) {
      return {
        code: -999,
        message: '参数不正确'
      }
    } else {
      destory(objectId)
      List = List.filter(u => u.objectId !== objectId)
      return {
        code: 200,
        data: {
          message: '删除成功'
        }
      }
    }
  },
  /**
   * 批量删除
   * @param config
   * @return {{code: number, data: {message: string}}}
   */
  batchremoveMoney: config => {
    console.log(config);
    // console.log(mUtils.param2Obj(config.url));
    let { ids } = mUtils.param2Obj(config.url)
    console.log(ids);
    ids = ids.split(',')
    List = List.filter(u => !ids.includes(u.id))
    return {
      code: 200,
      data: {
        message: '批量删除成功'
      }
    }
  },
  /**
   * 修改用户
   * @param id, name, addr, age, birth, sex
   * @return {{code: number, data: {message: string}}}
   */

  // 编辑操作涉及添加父亲（已存在），添加妻子（已存在），修改姓名，生日，性别
  updateMoney: config => {
    const { objectId,username, birthday, wife_name, gender, wife_bir, father_name, father_bir} = mUtils.param2Obj(config.url)
    List.some(u => {
      if (u.objectId === objectId) {
        const query = Bmob.Query('Person');
        query.get(objectId).then(res => {
          res.set('wife_name', wife_name)
          res.set('wife_bir', wife_bir)
          res.set('father_name', father_name)
          res.set('father_bir', father_bir)
          res.set('username', username)
          res.set('birthday', birthday)
          res.set('geder', gender)
          res.save()
        }).catch(err => {
          console.log(err)
        })
        u.father_name = father_name
        u.wife_bir = wife_bir
        u.father_bir = father_bir
        u.username = username
        u.birthday = birthday
        u.wife_name = wife_name
        u.gender = gender
        return true
      }
    })
    return {
      code: 200,
      data: {
        message: '编辑成功'
      }
    }
  }
}