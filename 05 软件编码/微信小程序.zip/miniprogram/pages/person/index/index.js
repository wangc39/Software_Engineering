let WxNotificationCenter = require('../../../config/WxNotificationCenter.js');
var Bmob=require("../../../dist/Bmob.js");
import * as echarts from '../../../ec-canvas/echarts';

import { Loading, Toast } from '../../../dist/index';
import {cal_relation,getObjectById} from '../../../dist/util';
// var utils=require('../../dist/util.js')
let app = getApp();
let systemInfo = wx.getSystemInfoSync();
let windowWidth = systemInfo.windowWidth;
let windowHeight = systemInfo.windowHeight;
let fileSystemManager = wx.getFileSystemManager();



Page({

  /**
   * 页面的初始数据
   */
  data: {

    ec:{onInit: null},
    relation_string: "",
    index: 0,
    currentBranch:null,
    Braches:null,
    currentNode:null,
    dataBmob:null,
    isiPhoneX: false,
    dataSource: null,
    dataSourceNear:null,
    windowWidth,
    showModal:false,
    width: 0,
    height: 0,
    destroy_msg:"",
    start_node:null,
    end_node:null,
    start_info:"起始节点",
    end_info:"终止节点",
    tabs2: [
      {
        text: '树状',
        icon: 'top',
        iconSize: '32rpx',
        iconColor: '#0905da',
      },
      {
        text: '统计',
        icon: 'share',
        iconSize: '32rpx',
        iconColor: '#0905da',
      },
      {
        text: '近亲',
        icon: 'user',
        iconSize: '32rpx',
        iconColor: '#0905da',
      },
      {
        text: '关系',
        icon: 'address-card',
        iconSize: '32rpx',
        iconColor: '#0905da',
      },
    ],
  },
  handleChange(e) {
    
    if(e.detail.value == 1){
      Loading.show({
        hide:()=>{Toast.show({message:"刷新成功", position:"bottom", })}
      })
      this.setData({
        ec:{onInit: this.initChart},
      })
      Loading.hide();

    }
    this.setData({
      index: e.detail.value,
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function(options) {
    // console.log(getApp().globalData.dataBmob)
    
    
    wx.setNavigationBarColor({
      frontColor: '#ffffff',
      backgroundColor: '#000000'
    })
    this.setData({
      isiPhoneX: app.globalData.isiPhoneX,
    });
    //读入数据
    this.readData();
    let that = this;
    ///添加点击节点的通知
    WxNotificationCenter.addNotification("NOTI_TREECLICK", that.itemClick, that);
    
  },
  onShow:function(options){
    this.setData({
      start_node:getApp().globalData.startNode,
      end_node:getApp().globalData.endNode,
    })
    if(getApp().globalData.currentNode != null){
      // console.log("sdfs");
      this.setData({
        showModal:true,
        currentNode:getApp().globalData.currentNode
      })
      
      getApp().globalData.currentNode = null;

    }
    // console.log(options)
    if(getApp().globalData.currentBranch != null){
      // console.log("sdfs");
      this.setData({
        currentBranch:getApp().globalData.currentBranch
      })
      console.log(getApp().globalData.currentBranch);
      var res = getApp().globalData.dataBmob;
      var person,index;
      // 找出根对应的人的信息
      index = this.data.currentBranch;
      console.log(index)
      
      person = res[index]

      // 根据根节点构建树
      var individual = this.makeTree(index,person,res,0);
      this.setData({
        dataSource: individual,
      })
      getApp().globalData.currentBranch = null;
    }
    if(app.globalData.is_fresh){
      // 防止查询节点已经被删除
      this.setData({
        start_node:null,
        end_node:null,
      })
      this.onLoad(options);
      getApp().globalData.is_fresh = false;
    }
    // this.onLoad(options);
  },
  onUnload: function() {
    let that = this;
    ///移除通知
    WxNotificationCenter.removeNotification(NOTI_TREECLICK, that);
    WxNotificationCenter.removeNotification(NOTI_TREEEDIT, that);
  },
  ///节点点击
  itemClick: function(event) {

    console.log(event);
    this.setData({
      showModal:true,
      currentNode:getApp().globalData.dataBmob[event.self_index]});
    // console.log(this.data.currentNode)
  },
  ///读取数据
  readData: function() {
    //查询分支表，里面记录了所有旁支的头节点
    var resBranch = getApp().globalData.dataBranch;
    this.setData({Braches:resBranch,currentBranch:resBranch[0]});//置当前分支为分支表记录的第一个分支
      
    
    var person,index;
    var res = getApp().globalData.dataBmob;
    // 找出根对应的人的信息
    index = this.data.currentBranch;
    person = res[index]
    

    this.setData({dataBmob:res})
    // 根据根节点构建树
    var individual = this.makeTree(index,person,res,0);
    // 构建近邻树
    var little = this.makeNearTree(getApp().globalData.selfNode,res);
      this.setData({
        dataSource: individual,
        dataSourceNear:little,
      })
      
      if(index == 0){
        if (this.data.dataSource) {
          let that = this;
          ///渲染完成后获取子组件大小重新设置宽高
          wx.createSelectorQuery().select('#rootTree').boundingClientRect(function(rect) {
            that.setData({
              width: rect.width > windowWidth ? rect.width : windowWidth,
              height: rect.height > windowHeight ? rect.height : windowHeight,
            })
          }).exec();
        }
      }

    
    
      
    
  },
  makeTree: function(index,person,res,level){
    
    var individual = {
      objectId: person.objectId,
      thumb: person.thumb,

      isBind:person.isBind,
      name:person.username,
      is_wife: person.is_wife,
      gender:person.gender,
      children: [],
      child_index:[],
      level:level,
      self_index: index,
    };
    getApp().globalData.dataBmob[index].level = level;
    getApp().globalData.dataBmob[index].self_index = index;
    let keyArray = new Array();
    for(let i in person){keyArray.push(i)}
    // console.log(person);
    // 如果有妻子，添加妻子
    if(person.wife != '' && keyArray.indexOf("wife") != -1)
    { 
      var result;
      result = getObjectById(person.wife,res) 
      individual.wife = this.makeTree(result.index,result.person,res,0)

      getApp().globalData.dataBmob[index].wife_index = result.index;
      getApp().globalData.dataBmob[result.index].husband_index = index;
      getApp().globalData.dataBmob[result.index].level = level;
      individual.wife_index = result.index;
      individual.wife.husband_index = index;
    }
    // 如果有孩子，以孩子为根结点构建子树
    if(keyArray.indexOf("children") != -1){
      level += 1;
      getApp().globalData.dataBmob[index].child_index = []
      for(let i in person.children){
        var result;
        result = getObjectById(person.children[i],res);
        result.person.father_index = index;

        getApp().globalData.dataBmob[index].child_index.push(result.index);
        getApp().globalData.dataBmob[result.index].father_index = index;

        individual.child_index.push(result.index);
        individual.children.push(this.makeTree(result.index,result.person,res,level));
      }
    }
    return individual;
  },
  makeNearTree: function(selfNode,res){
    var result = getObjectById(selfNode.objectId,res);
    var person = getApp().globalData.dataBmob[result.index];
    var upLevel = 2;
    if(person.level < 3){upLevel = person.level}
    for(let i = 0;i < upLevel;i++){
      person = getApp().globalData.dataBmob[person.father_index];
    }
    
    var individual = this.makeNearTreeRNN(person,person.level);
    return individual;
  },
  makeNearTreeRNN:function(person,startLevel){
    // console.log(person);
    var individual = {
      objectId: person.objectId,
      thumb: person.thumb,
      relationid: person.relationid,
      isBind:person.isBind,
      name:person.username,
      is_wife: person.is_wife,
      gender:person.gender,
      child:person.child,
      children: [],
      child_index:[],
      self_index: person.self_index,
    };
    let keyArray = new Array();
    for(let i in person){keyArray.push(i)}
    if(person.wife != '' && keyArray.indexOf("wife") != -1)
    { 
      var result;
      result = getApp().globalData.dataBmob[person.wife_index];
      individual.wife = this.makeNearTreeRNN(result,startLevel)

      individual.wife_index = result.self_index;
      individual.wife.husband_index = person.self_index;
    }
    if(person.level - 6 < startLevel){
      if(keyArray.indexOf("children") != -1){
        for(let i in person.children){
          var result;
          result = getApp().globalData.dataBmob[person.child_index[i]];
          result.father_index = person.self_index;
  
          individual.child_index.push(result.self_index);
          individual.children.push(this.makeNearTreeRNN(result,startLevel));
        }
      }
    }
    return individual;
  },
  showCancelOrder: function() {
    this.setData({
      showModal:true
    })
  },
  modal_click_Hidden: function () {
    this.handleDestroy();
    this.setData({
      showModal: false,
    })
  },
  handleUpdate:function(){
    this.setData({showModal:false});
    wx.navigateTo({
      url: '../updatePerson/updatePerson?Person='+JSON.stringify(this.data.currentNode),
    })
  },
  handleAdd:function(){

    let mesg = this.data.currentNode;
    // if(this.data.currentNode.is_wife == "1"){
    //   mesg.husband = getApp().globalData.dataBmob[mesg.];
    //   mesg.husband = this.getHunsband(this.data.currentNode.objectId,this.data.dataBmob);
    // }
    
    this.setData({showModal:false});
    wx.navigateTo({
      url: '../add/add?Person='+JSON.stringify(mesg),
    })
  },
  handleClose(){
    this.setData({
      
      showModal: false,
   
    });
  },
  destroyChildren(father){
    var keyArray = new Array();
    for(let i in father){
      keyArray.push(i);
    }
    if(keyArray.indexOf("children") != -1){
      for(let i in father.children){
        var childNode = getObjectById(father.children[i],this.data.dataBmob);
        this.destroyChildren(childNode);
        // console.log(father.children[i]);
      }
    }
   
    if(keyArray.indexOf("wife") != -1 && father.wife != ''){
      var wifeNode = getObjectById(father.wife,this.data.dataBmob);
      console.log(wifeNode);
      this.destroyChildren(wifeNode);
        // console.log(father.children[i]);
    }
    var destroyQuery = new Bmob.Query("Person");
    destroyQuery.destroy(father.objectId).then(res=>{
      console.log(father.username + "已删除");
    }).catch(error=>{
      console.log(error);
    })
  },


  handleDestroy() {
    var del = Bmob.Query("apply"); 
    del.set("operation",1);
    del.set("Node1",this.data.currentNode.objectId);
    if (this.data.currentNode.wife_index){
      let wife = getApp().globalData.dataBmob[this.data.currentNode.wife_index];
      del.set("wife_name",wife.username);
      del.set("wife_birthday",wife.birthday);
    }
    if (this.data.currentNode.father_index){
      let father = getApp().globalData.dataBmob[this.data.currentNode.father_index];
      del.set("father_name",father.username);
      del.set("father_birthday",father.birthday);
    }

    
    del.save().then(res=>{
      Toast.show({
        message:"已提交",
        position:"bottom"
      })
    })
    
    // Loading.show({
    //   hide: ()=> {
    //     // console.log(if_success)
    //       Toast.show({
    //         position: 'bottom',
    //         message: this.data.destroy_msg,
    //       })

    //     },
      
    // });

    // if(this.data.currentNode.is_wife == "0"){
    //   var father = this.getFather(this.data.currentNode.objectId,this.data.dataBmob);
    //   if(!father){
    //     // Toast.show({
    //     //   message: "删了这个就全没了",
    //     //   position: 'bottom',
    //     // })
    //     this.setData({destroy_msg: "删了这个就全没了"})
    //     Loading.hide();
    //     return ;
    //   };
    //   var bmobQuery = new Bmob.Query("Person");
    //   bmobQuery.set("id",father.objectId);
    //   father.children.splice(father.children.indexOf(this.data.currentNode.objectId),1);
    //   bmobQuery.set("children",father.children);
    //   bmobQuery.save().then(res=>{
    //     this.destroyChildren(this.data.currentNode);
    //     this.setData({destroy_msg: "已销毁"})
    //     Loading.hide()
    //     this.onLoad();
    //     console.log("success");
    //   }).catch(error=>{
    //     console.log(error);
    //   })


    // }else{
    //   var husband = this.getHunsband(this.data.currentNode.objectId,this.data.dataBmob);
    //   var bmobQuery = new Bmob.Query("Person");
    //   bmobQuery.set("id",husband.objectId);
    //   // father.children.splice(father.children.indexOf(this.data.currentNode.objectId),1);
    //   bmobQuery.set("wife",'');
    //   bmobQuery.save().then(res=>{
    //     var destroyQuery = new Bmob.Query("Person");
    //     destroyQuery.destroy(this.data.currentNode.objectId).then(res=>{
    //       console.log(this.data.currentNode.username + "已删除");
    //     }).catch(error=>{
    //       console.log(error);
    //     })
    //     Loading.hide(1)
    //     this.onLoad();
    //     console.log("success");
    //   }).catch(error=>{
    //     console.log(error);
    //   })
    // }
   
    
    
    this.setData({
      
      showModal: false,
   
    });
  },
  startNode:function(){
    console.log("sdasda");
    wx.navigateTo({
      url: '../search/search?node=start'
    })
  },
  endNode:function(){
    wx.navigateTo({
      url: '../search/search?node=end'
    })
  },

   
  searchForRelation:function(){
    if(!this.data.start_node || !this.data.end_node){
      Toast.show({message:"请填写节点信息",position:"bottom"});
      return
    }
    // console.log(utils)
    this.setData({relation_string:cal_relation(this.data.start_node,this.data.end_node)})
    console.log(this.data.relation_string);
  },
  personToLinearNode:function(individual){
    var linearNode = new Object();
    // console.log(individual);
    linearNode.name = individual.name;
    
    linearNode.children = []
    for(let i in individual.children){linearNode.children.push(this.personToLinearNode(individual.children[i]))};
    return linearNode;
  },
  initChart: function(canvas, width, height, dpr) {
    // var nodeData = this.data.dataSource;
    var dataBar = this.getDataBar();
    // var nodeData = this.personToLinearNode(this.data.dataSource);
    const chart = echarts.init(canvas, null, {
      width: width,
      height: height,
      devicePixelRatio: dpr // new
    });
    canvas.setChart(chart);
    
    var option = {
      color: ['#37a2da', '#e01a76'],
      tooltip: {
        trigger: 'axis',
        axisPointer: {            // 坐标轴指示器，坐标轴触发有效
          type: 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
        },
        confine: true
      },
      legend: {
        data: ['男', '女']
      },
      grid: {
        left: 20,
        right: 20,
        bottom: 15,
        top: 40,
        containLabel: true
      },
      xAxis: [
        {
          type: 'value',
          axisLine: {
            lineStyle: {
              color: '#999'
            }
          },
          axisLabel: {
            color: '#666'
          }
        }
      ],
      yAxis: [
        {
          type: 'category',
          axisTick: { show: false },
          data: ['1950以前出生', '1950-70', '1970-80', '1980-90', '1990-2000', '2000-2010', '2010至今出生'],
          axisLine: {
            lineStyle: {
              color: '#999'
            }
          },
          axisLabel: {
            color: '#666'
          }
        }
      ],
      series: [
        {
          name: '男',
          type: 'bar',
          label: {
            normal: {
              show: true,
              position: 'inside'
            }
          },
          data: dataBar[0],
          itemStyle: {
            // emphasis: {
            //   color: '#37a2da'
            // }
          }
        },
        {
          name: '女',
          type: 'bar',
          stack: '总量',
          label: {
            normal: {
              show: true
            }
          },
          data: dataBar[1],
          itemStyle: {
            // emphasis: {
            //   color: '#32c5e9'
            // }
          }
        }
      ]
    };
    chart.setOption(option);

    return chart;
  },
  // 得到统计信息
  getDataBar:function(){
    // 两个数组，数组1代表男性，数组2代表女性
    var data = [[0,0,0,0,0,0,0],[0,0,0,0,0,0,0]];
    // 从用户列表中遍历
    for(let i in this.data.dataBmob){
      var person = this.data.dataBmob[i];
      var year = person.birthday.split("-")[0]; //获取对应用户出生年份
      var idx = Math.trunc((Number(year)-1950)/10); //计算该年份落在数组的哪个位置
      idx = idx = idx > 0 ? idx : 0; // 小于1950的都算第一个
      idx = idx > 6 ? 6 : idx; //2010之后的
      if(person.gender == "男"){
        data[0][idx] += 1;
      }else{
        data[1][idx] += 1;
      }
    }
    return data;
  },
  toSearch:function(){
    // console.log("hello");
    
    wx.navigateTo({
      url: '../search/search?',
    })
  },
  searchRoot: function(){
    console.log("esf");
    wx.navigateTo({
      url: '../rootList/rootList',
    })
  }
})