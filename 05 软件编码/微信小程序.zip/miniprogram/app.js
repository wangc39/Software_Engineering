//app.js
var Bmob=require("dist/Bmob.js");
// Bmob.initialize("965bd5435f688777335dafcac521255f", "e5d2d945a29693e97a677650946ba68f");

// Bmob.initialize("你的Secret Key", "你的API 安全码");
Bmob.initialize("f5548270aaba8ebe","674436");
App({
  onLaunch() {
    // 展示本地存储能力
    const logs = wx.getStorageSync('logs') || []
    logs.unshift(Date.now())
    wx.setStorageSync('logs', logs)

    // 登录
    wx.login({
      success: res => {
        // 发送 res.code 到后台换取 openId, sessionKey, unionId
      }
    })
  },
   getUserInfo:function(cb){
    var that = this
  },
  globalData: {
    selfnode:null,
    isiPhoneX: false,
    userInfo:null,
    is_fresh:false,
    dataBmob:null,
    startNode:null,
    endNode:null,
    userInfo: null,
  },
  onShow: function () {
    let that = this;
    ///获取机型 iPhoneX适配
    wx.getSystemInfo({
      success: function (res) {
        let model = res.model;
        that.globalData.isiPhoneX = model.search('iPhone X') != -1;
      },
    });
  }
})    