const zh = {
    // layout
    commons: {
      xiaoai: '族谱.',
      admin: 'Admin',
      editor: 'Editor',
      quit: 'Sign Out',
      hi: 'Hi',
      index: '消息发布',
      userManage: '消息发布',
      fundManage: '族谱管理',
      userList: '用户管理',
      applyList: '审核管理',

      page401:'401',
      page404:'404',

    },
    index:{

    }
  }
  
export default zh;