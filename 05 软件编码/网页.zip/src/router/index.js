import Vue from 'vue'
import Router from 'vue-router'
import { Layout,Content }  from "../layout"; // 页面整体布局
import { topRouterMap } from "./topRouter";

  
// const originalPush = Router.prototype.push
// Router.prototype.push = function push(location, onResolve, onReject) {
//  if (onResolve || onReject) return originalPush.call(this, location, onResolve, onReject)
//  return originalPush.call(this, location).catch(err => err)
// }
process.env.NODE_ENV === "development" ? Vue.use(Router) : null;

function filterTopRouterMap(name){
	let router = topRouterMap.find((item) => {
		return item.parentName === name;
	});
	return router.data; // arr
}

/**
 * 1、roles:后台返回的权限结构;
 * 
 */
//手动跳转的页面白名单
const whiteList = [
	'/'
];
/**
 * path:''与path:'*'的区别：
 * 1、path:'*', 会匹配所有路径
 * 2、path:''，也是会匹配到路由
 * 
 */
//默认不需要权限的页面
export const constantRouterMap = [
	{
    path: '',  
    component: Layout,
		redirect: '/index/index',
		hidden:true
  },
	{ path: '/login',name: 'login',component:() => import('@/page/login'),hidden: true},
	{ path: '/404', component: () => import('@/page/errorPage/404'), hidden: true },
  { path: '/401', component: () => import('@/page/errorPage/401'), hidden: true },
	{
		path: '/index',
		name: 'index',
		component:Layout,
		meta:{
			title:'消息发布',
		  icon: 'icondashboard',
		},
		noDropdown:true,
		children:[ 
			{
				path:'index', 
				meta:{
					title:'消息发布', 
					icon:'icondashboard',
				  routerType:'leftmenu'
				},
        component: () => import('@/page/index/index'),
			}
		]
	}

]

	//注册路由
export default new Router({
	mode:'history', // 默认为'hash'模式
	// base: process.env.BASE_URL,
	base: '/permission/', // 添加跟目录,对应服务器部署子目录
	routes: constantRouterMap
})

  //异步路由（需要权限的页面）
export const asyncRouterMap = [

	{
		path:'/fundManage',
		name: 'fundManage',
		meta: {
		  title:'族谱管理',
		  icon: 'iconpay3',
		},
		component:Layout,
		children:[
		  {
			path:'userList',
			name:'userList',
			meta: {
					title:'用户管理',
					routerType:'leftmenu'
			},
			component: () => import('@/page/userList/userList'),
		  },
		  {
			path:'applyList',
			name:'applyList',
			meta: {
				title:'审核管理',
				routerType:'leftmenu'
			},
			component: () => import('@/page/userList/applyList'),
			}
		]
	},
	{ path: '*', redirect: '/404', hidden: true }
	];
	

