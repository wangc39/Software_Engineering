<template>
    <el-dialog 
        :visible.sync="isVisible"
        :title="addFundDialog.title" 
        :close-on-click-modal='false'
        :close-on-press-escape='false'
        :modal-append-to-body="false"
        @close="closeDialog">
        <div class="form">
            <el-form 
                ref="form" 
                :model="form"
                :rules="form_rules"
                :label-width="dialog.formLabelWidth" 
                style="margin:10px;width:auto;">
                <!--<el-form-item prop='incomePayType' label="收支类型:" >
                    <el-select v-model="form.incomePayType" placeholder="收支类型">
                        <el-option
                            v-for="item in payType"
                            :key="item.value"
                            :label="item.label"
                            :value="item.value">
                        </el-option>
                    </el-select>
                </el-form-item>-->
                <el-form-item prop='father_name' label="父亲姓名:">
                    <el-input type="text" v-model="form.father_name"></el-input>
                </el-form-item>
                <el-form-item prop='father_bir' label="父亲生日:">
                    <el-input type="text" v-model="form.father_bir"></el-input>
                </el-form-item>    
                <el-form-item prop='username' label="姓名:">
                    <el-input type="text" v-model="form.username"></el-input>
                </el-form-item>
                <el-form-item prop='gender' label="性别:">
                    <el-input type="text" v-model="form.gender"></el-input>
                </el-form-item>
                <el-form-item prop='birthday' label="生日:">
                    <el-input type="text" v-model="form.birthday"></el-input>
                </el-form-item>    
                <el-form-item prop='wife_name' label="配偶姓名:">
                    <el-input type="text" v-model="form.wife_name"></el-input>
                </el-form-item>
                <el-form-item prop='wife_bir' label="配偶生日:">
                    <el-input type="text" v-model="form.wife_bir"></el-input>
                </el-form-item>    



                <el-form-item  class="text_right">
                    <el-button @click="isVisible = false">取 消</el-button>
                    <el-button type="primary" @click='onSubmit("form")'>提  交</el-button>
                </el-form-item>

            </el-form>
        </div>
    </el-dialog>
</template>

<script>
   import { mapState, mapGetters } from 'vuex'
   import { addMoney,updateMoney } from "@/api/usermanger";
   //import AreaJson from "@/assets/datas/area.json"
   import Bmob from '@/dist/Bmob-2.2.5.min.js'
   Bmob.initialize("f5548270aaba8ebe","674436")

   function updateLevel(fatherId){
        const query = Bmob.Query('Person');
        query.get(fatherId).then(res => {
            var j;
            let flevel = res.level;
            for(j = 0; j < res.children.length; j++){
                const cquery = Bmob.Query('Person');
                query.get(res.children[j]).then(cres => {
                    cres.set('level', flevel+1)
                    cres.save()
                    updateLevel(res.children[j])
                }).catch(err => {
                console.log(err)
                })
            }
        
        }).catch(err => {
        console.log(err)
        })

   }
  export default {
      name:'addFundDialogs',
      data(){
          let validateData = (rule, value, callback) => {
                if(value === ''){
                    let text;

                    callback(new Error(text+'不能为空~'));
                }else{
                   let numReg = /^[0-9]+.?[0-9]*$/;
                   if(!numReg.test(value)){
                      callback(new Error('请输入正数值'));
                   }else{
                      callback();
                   }
                }
            };
          return {
            areaData:[],
            isVisible: this.isShow,
            form:{
                father_name:'',
                father_bir:'',
                username: '',
                birthday: '',
                gender:'',
                wife_name:'',
                wife_bir:'',
            },
            payType:[

            ],
            form_rules: {
                username   : [
                    {required: true, message : '姓名不能为空！',trigger : 'blur'}
                ],
                gender   : [
                    {required: true, message : '性别不能为空！',trigger : 'blur'}
                ],
                birthday   : [
                    {required: true, message : '生日不能为空！',trigger : 'blur'}
                ],
            },
            //详情弹框信息
            dialog: {
                width:'400px',
                formLabelWidth:'120px'
            }
          }
      },
      props:{
          isShow:Boolean,
          dialogRow:Object
      },
      computed:{
        ...mapGetters(['addFundDialog']),
      },
      created(){
            //this.areaData = AreaJson
      },
      mounted(){
        if(this.addFundDialog.type === 'edit'){
            this.form = this.dialogRow;
            console.log(this.form);
            this.form.incomePayType = (this.dialogRow.incomePayType).toString();
            // this.form.address = ["120000", "120200", "120223"]

        }else{
            this.$nextTick(() => {
                this.$refs['form'].resetFields()
            })
        }
      },
      methods:{
          getCascaderObj(val, opt){
            return val.map(function (value, index, array) {
                for (var item of opt) {
                    if (item.value == value) { 
                        opt = item.children; 
                        return item.label; 
                    }
                }
                return null;
            });
         },
          handleChange(value) {
            console.log([...value]); // ["120000", "120200", "120223"]
            this.form.address = [...value];
            let vals = this.getCascaderObj([...value], this.areaData); // arr
            this.form.tableAddress = vals.join(',').replace(/,/g,'');
          },
          closeDialog(){
              this.$emit('closeDialog');
          },
          //表单提交
          onSubmit(form){
            this.$refs[form].validate((valid) => {
                if (valid) {//表单数据验证完成之后，提交数据;
                    let formData = this[form];
                    const para = Object.assign({}, formData)
                    console.log(para);
                    // edit
                    if(this.addFundDialog.type === 'edit'){
                        updateMoney(para).then(res => {
                            this.$message({
                                message: '修改成功',
                                type: 'success'
                            })
                            this.$refs['form'].resetFields()
                            this.isVisible = false
                            this.$emit('getFundList');
                       })
                    }else{
                        // add
                        var myid;
                        const query = Bmob.Query('Person');
                        query.set("username",para.username)
                        query.set("birthday",para.birthday)
                        query.set("gender", para.gender)
                        query.set("wife_name", para.wife_name)
                        query.set("wife_bir", para.wife_bir)
                        query.set("father_name", para.father_name)
                        query.set("father_bir", para.father_bir)
                        if(para.wife_name){
                            query.set('is_wife', '1')
                        }
                        else{
                            query.set('is_wife', '0')
                        }
                        //查找父亲节点，存在，level置为父亲节点+1
                        //父亲节点的孩子数组 添加新objectId
                        let fList = []
                        var branch = 0
                            const fquery = Bmob.Query("Person");
                            fquery.equalTo("username","==", para.father_name);
                            fquery.equalTo("birthday", "==", para.father_bir);
                            fquery.find().then(res => {
                                if(res.length > 0){
                                    query.set('level', res[0].level + 1)
                                }
                                else{
                                    query.set('level', 0)
                                    branch = 1
                                }

                        query.save().then(res => {
                            myid = res.objectId
                            console.log(res)
                            if(para.gender == '男' && branch == 1){
                                const branquery = Bmob.Query('Branch');
                                branquery.set("name",para.username)
                                branquery.set("personid", myid)
                                branquery.save().then(branres => {
                                console.log(branres)
                                }).catch(err => {
                                console.log(err)
                                })
                            }
                            //找到父亲节点
                            const pfquery = Bmob.Query("Person");
                            pfquery.equalTo("username","==", para.father_name);
                            pfquery.equalTo("birthday", "==", para.father_bir);
                            pfquery.find().then(fres => {
                                if(fres[0].objectId){
                                    const ffquery = Bmob.Query('Person');
                                    ffquery.get(fres[0].objectId).then(ffres => {
                                    let cList = []
                                    if(ffres.children){
                                    cList = JSON.parse(JSON.stringify(ffres.children)); 
                                    cList.push(myid)
                                    }
                                    else{
                                        cList.push(myid)
                                    }
                                    ffres.set('children',cList)
                                    ffres.save()
                                    }).catch(err => {
                                    console.log(err)
                                    })
                                }
                            });
                            //找到配偶节点
                            const nfquery = Bmob.Query("Person");
                            nfquery.equalTo("username","==", para.wife_name);
                            nfquery.equalTo("birthday", "==", para.wife_bir);
                            nfquery.find().then(fres => {
                                if(fres[0].objectId){
                                    const ffquery = Bmob.Query('Person');
                                    ffquery.get(fres[0].objectId).then(ffres => {
                                    ffres.set('wife_name', para.name)
                                    ffres.set('wife_bir', para.birthday)
                                    if(para.gender == '女'){
                                        ffres.set('wife',myid)
                                    }
                                    
                                    ffres.save()
                                    }).catch(err => {
                                    console.log(err)
                                    })
                                }
                            });
                            }).catch(err => {
                            console.log(err)
                            
                        })
                            });
                        
                        

                        addMoney(para).then(res => {
                            this.$message({
                                message: '新增成功',
                                type: 'success'
                            })
                            this.$refs['form'].resetFields()
                            this.isVisible = false
                            this.$emit('getFundList');
                       })
                    }
                }
            })
          }
      }
  }
</script>

<style lang="less" scoped>
    .search_container{
        margin-bottom: 20px;
    }
    .btnRight{
        float: right;
        margin-right: 0px !important;
    }
    .searchArea{
        background:rgba(255,255,255,1);
        border-radius:2px;
        padding: 18px 18px 0;
    }
</style>
