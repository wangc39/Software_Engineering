// components/menu/menu.js
Component({
  /**
   * 组件的属性列表
   */
  properties: {
  
  },

  /**
   * 组件的初始数据
   */
  data: {
    showmenus:true,
    menulist:[
      {
        "id":"1",
        "url":"../../images/top.png",
        "title":"顶部",
      },
      {
        "id": "2",
        "url": "../../images/add.png",
        "title": "添加",
      },],
  },

  /**
   * 组件的方法列表
   */
  methods: {
    showclick:function(){
      console.log("showclick")
      let isshow = !this.data.showmenus;
      console.log(isshow)
      this.setData({
        showmenus: isshow,
      })
    },
    itemclick:function(e){
      this.showclick();
      console.log(e.currentTarget.dataset);
      let info = e.currentTarget.dataset.item;
      if (info){
        this.triggerEvent('menuItemClick', {
            "iteminfo":info
        })
      }
    }
   

  }
})
