// pages/create/create.js

var Bmob=require("../../dist/Bmob.js");

Page({

  /**
   * 页面的初始数据
   */
  data: {
    textData: " ",
    objId: "", 
    BmobData: []
  },
  
  treeShow: function(){
    // wx.navigateTo({
    //   url: '../index/index',
    // })
    wx.switchTab({
      url: '../index/index',
    });
  },
 
  uploadData: function(){
    let jsonData = "{\"name\":\"\",\"relationid\":34,\"username\":\"何先生\",\"gender\":0,\"thumb\":\"https://wx.qlogo.cn/mmopen/vi_32/Q0j4TwGTfTIpYoDe6gaZwdbLsZSohOBLgbOib6GCOCn9ulwjXUm4v26HeqA05n0VEWLib7QbBowreO9PUamOrB0w/132\",\"level\":null,\"child\":\"35,36,51\",\"is_wife\":\"0\",\"isBind\":1,\"isself\":true,\"children\":[{\"name\":\"郭先生\",\"relationid\":35,\"gender\":0,\"username\":\"郭先生\",\"thumb\":\"\",\"level\":3,\"child\":\"37,43\",\"is_wife\":\"0\",\"isBind\":0,\"isself\":false,\"wife\":{\"name\":\"凤姐\",\"relationid\":43,\"gender\":1,\"username\":\"凤姐\",\"thumb\":\"\",\"level\":3,\"child\":null,\"is_wife\":\"1\",\"isBind\":0,\"isself\":false},\"children\":[{\"name\":\"吴先生\",\"relationid\":37,\"gender\":0,\"username\":\"吴先生\",\"thumb\":\"\",\"level\":3,\"child\":\"38,39,42,45\",\"is_wife\":\"0\",\"isBind\":0,\"isself\":false,\"wife\":{\"name\":\"乔碧萝\",\"relationid\":42,\"gender\":1,\"username\":\"乔碧萝\",\"thumb\":\"\",\"level\":3,\"child\":null,\"is_wife\":\"1\",\"isBind\":0,\"isself\":false},\"children\":[{\"name\":\"严先生\",\"relationid\":38,\"gender\":0,\"username\":\"严先生\",\"thumb\":\"\",\"level\":3,\"child\":null,\"is_wife\":\"0\",\"isBind\":0,\"isself\":false},{\"name\":\"张先生\",\"relationid\":39,\"gender\":0,\"username\":\"张先生\",\"thumb\":\"\",\"level\":3,\"child\":\"44\",\"is_wife\":\"0\",\"isBind\":0,\"isself\":false,\"wife\":{\"name\":\"蔡徐坤\",\"relationid\":44,\"gender\":1,\"username\":\"蔡徐坤\",\"thumb\":\"\",\"level\":3,\"child\":null,\"is_wife\":\"1\",\"isBind\":0,\"isself\":false}},{\"name\":\"陈先生\",\"relationid\":45,\"gender\":0,\"username\":\"陈先生\",\"thumb\":\"\",\"level\":3,\"child\":\"49,58\",\"is_wife\":\"0\",\"isBind\":0,\"isself\":false,\"children\":[{\"name\":\"邓先生\",\"relationid\":49,\"gender\":0,\"username\":\"邓先生\",\"thumb\":\"\",\"level\":3,\"child\":\"50\",\"is_wife\":\"0\",\"isBind\":0,\"isself\":false,\"wife\":{\"name\":\"彭女士\",\"relationid\":50,\"gender\":1,\"username\":\"彭女士\",\"thumb\":\"\",\"level\":3,\"child\":null,\"is_wife\":\"1\",\"isBind\":0,\"isself\":false}},{\"name\":\"谭先生\",\"relationid\":58,\"gender\":0,\"username\":\"谭先生\",\"thumb\":\"\",\"level\":3,\"child\":\"59\",\"is_wife\":\"0\",\"isBind\":0,\"isself\":false,\"wife\":{\"name\":\"欧阳先生\",\"relationid\":59,\"gender\":1,\"username\":\"欧阳先生\",\"thumb\":\"\",\"level\":3,\"child\":null,\"is_wife\":\"1\",\"isBind\":0,\"isself\":false}}]}]}]},{\"name\":\"焦先生\",\"relationid\":36,\"gender\":0,\"username\":\"焦先生\",\"thumb\":\"\",\"level\":3,\"child\":\"41,46,47\",\"is_wife\":\"0\",\"isBind\":0,\"isself\":false,\"wife\":{\"name\":\"张女士\",\"relationid\":41,\"gender\":1,\"username\":\"张女士\",\"thumb\":\"\",\"level\":3,\"child\":null,\"is_wife\":\"1\",\"isBind\":0,\"isself\":false},\"children\":[{\"name\":\"黄先生\",\"relationid\":46,\"gender\":0,\"username\":\"黄先生\",\"thumb\":\"\",\"level\":3,\"child\":null,\"is_wife\":\"0\",\"isBind\":0,\"isself\":false},{\"name\":\"纪先生\",\"relationid\":47,\"gender\":0,\"username\":\"纪先生\",\"thumb\":\"\",\"level\":3,\"child\":\"48\",\"is_wife\":\"0\",\"isBind\":0,\"isself\":false,\"wife\":{\"name\":\"候女士\",\"relationid\":48,\"gender\":1,\"username\":\"候女士\",\"thumb\":\"\",\"level\":3,\"child\":null,\"is_wife\":\"1\",\"isBind\":0,\"isself\":false}}]},{\"name\":\"周先生\",\"relationid\":51,\"gender\":0,\"username\":\"周先生\",\"thumb\":\"\",\"level\":3,\"child\":\"52,53,54,55\",\"is_wife\":\"0\",\"isBind\":0,\"isself\":false,\"wife\":{\"name\":\"程先生\",\"relationid\":54,\"gender\":1,\"username\":\"程先生\",\"thumb\":\"\",\"level\":3,\"child\":null,\"is_wife\":\"1\",\"isBind\":0,\"isself\":false},\"children\":[{\"name\":\"李先生\",\"relationid\":52,\"gender\":0,\"username\":\"李先生\",\"thumb\":\"\",\"level\":3,\"child\":null,\"is_wife\":\"0\",\"isBind\":0,\"isself\":false},{\"name\":\"徐先生\",\"relationid\":53,\"gender\":0,\"username\":\"徐先生\",\"thumb\":\"\",\"level\":3,\"child\":\"57\",\"is_wife\":\"0\",\"isBind\":0,\"isself\":false,\"wife\":{\"name\":\"朱女士\",\"relationid\":57,\"gender\":1,\"username\":\"朱女士\",\"thumb\":\"\",\"level\":3,\"child\":null,\"is_wife\":\"1\",\"isBind\":0,\"isself\":false}},{\"name\":\"方先生\",\"relationid\":55,\"gender\":0,\"username\":\"方先生\",\"thumb\":\"\",\"level\":3,\"child\":\"56\",\"is_wife\":\"0\",\"isBind\":0,\"isself\":false,\"wife\":{\"name\":\"高女士\",\"relationid\":56,\"gender\":1,\"username\":\"高女士\",\"thumb\":\"\",\"level\":3,\"child\":null,\"is_wife\":\"1\",\"isBind\":0,\"isself\":false}}]}]}";
    var dataToShow = String();
    
    var dataUpload = JSON.parse(jsonData)
    // var queryArray = new Array();
    // this.makePerson(dataUpload);
    
    // dataToShow += this.showData(dataUpload,dataToShow);
    // this.setData({textData : dataToShow});
    this.appendArray(dataUpload);
  },
  getData:function(){
    console.log("begin");
    var currentNode = Bmob.Query("Person");
    currentNode.find().then(res=>{

      var list = [];
      for(let i in res){
        list.push({
          username: res[i].username,
          objectid: res[i].objectId
        })
      }
      this.setData({BmobData:list});
      console.log("ok");
    }).catch(err => {
      console.log(err);
    });
  },
  showData : function(uploadData,dataDoShow){
    const keyArray = new Array();
    
    for(var key in uploadData){
      keyArray.push(key);
      dataDoShow += (key + ": "+uploadData[key] +"\n");
    }
    // console.log(keyArray.indexOf("wife"));
    // console.log(keyArray.indexOf("children"));
    if(keyArray.indexOf("wife") != -1){
      dataDoShow = this.showData(uploadData.wife,dataDoShow);
    }
    if(keyArray.indexOf("children") != -1){
      for(var chi in uploadData.children){
        dataDoShow = this.showData(uploadData.children[chi],dataDoShow);
      }
    }
    return dataDoShow;
  },
  appendArray: function(person){
    let currentObjectId = String();
    // currentObjectId.push("sid")
    console.log(this.data.BmobData[1].objectid);
    for(let i in this.data.BmobData){
      if(this.data.BmobData[i].username == person.username){
        currentObjectId += String(this.data.BmobData[i].objectid);
        break;
      }
        
    }
      // const query = Bmob.Query('Person');
      // query.set('id', currentObjectId.objectId) //需要修改的objectId
      // query.set('gender', 9)
      // query.save().then(res => {
      // console.log(res)
      // }).catch(err => {
      // console.log(err)
      // })
      const updateQuery = Bmob.Query('Person');
  
      
      // console.log(person.username);
      updateQuery.set('id', currentObjectId)
      var keyArray = new Array();
      // var PointId = Bmob.Pointer('Person');
      // var RelatId;
      for(var key in person){
        keyArray.push(key);
      }
      // 返回 isLike > 150 or isLike < 5 的值
      if(keyArray.indexOf("wife")!= -1){
        // var pointer = Bmob.Pointer('Person')
        // var poiID = pointer.set(this.getObject(person.wife.username));
  
        updateQuery.set("wife",this.getObjectByName(person.wife.username));
      }
      var childrenArray = new Array();
      if(keyArray.indexOf("children") != -1){
        for (let pers in person.children){
          this.appendArray(person.children[pers]);
          childrenArray.push(this.getObjectByName(person.children[pers].username));
        }
        // const relation = Bmob.Relation('Person') // 需要关联的表
        // const relID = relation.add(childrenArray) 
        updateQuery.set("children",childrenArray);
      }
 
    updateQuery.save().then(res => {
      console.log(res)
      }).catch(err => {
      console.log(err)
      })
  },
  getObjectByName: function(username){
    for(let i in this.data.BmobData){
      if(this.data.BmobData[i].username == username){
        return String(this.data.BmobData[i].objectid);
      }
    }
  },
  makePerson: function(dataUpload){
    var queryObj = Bmob.Query("Person");
    queryObj.set("name",String(dataUpload.name));
    queryObj.set("relationid",Number(dataUpload.relationid));
    queryObj.set("username",String(dataUpload.username));
    queryObj.set("gender",Number(dataUpload.gender));
    queryObj.set("thumb",String(dataUpload.thumb));
    queryObj.set("level",Number(dataUpload.level));
    // queryObj.set("child",Array(dataUpload.child));
    queryObj.set("child",String(dataUpload.child));
    queryObj.set("is_wife",String(dataUpload.is_wife));
    queryObj.set("isBind",Number(dataUpload.isBind));
    queryObj.set("isself",Boolean(dataUpload.isself));
    const keyArray = new Array();
    for(var key in dataUpload){
      keyArray.push(key);
    }
    if(keyArray.indexOf("wife")!= -1){
      // const pointer = Bmob.Pointer('Person')
      // const poiID = pointer.set(this.makePerson(dataUpload.wife).objectId);
      this.makePerson(dataUpload.wife);
    }
        
    var ChildArray = new Array();
    if(keyArray.indexOf("children") != -1){
      for (let pers in dataUpload.children){
          this.makePerson(dataUpload.children[pers]);
        }
    }
    // console.log(ChildArray[0]);
    queryObj.set("children",ChildArray);
    // console.log(queryObj.setData.children);
    queryObj.save().then(res => {
      console.log(res)
    }).catch(err => {
      console.log(err)
    })
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    
  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})