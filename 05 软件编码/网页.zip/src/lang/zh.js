const zh = {
    // layout
    commons: {
      xiaoai: '一族一谱',
      admin: '管理员',
      editor: '  ',
      quit: '退出',
      hi: '您好',
      index: '消息发布',
      userManage: '消息发布',
      fundList: '用户管理',
      chinaTabsList: '审核管理',
      directivePer: '按钮权限',
      errorPage: '错误页面',
      page401:'401',
      page404:'404',
    },
    index:{
    }
  }
  
export default zh;