import request from '@/utils/axios'

export function getMoneyIncomePay(params) {
  return request({
    url: '/apply/get',
    method: 'get',
    params: params
  })
}

export function addMoney(params) {
  return request({
    url: '/apply/add',
    method: 'get',
    params: params
  })
}

export function removeMoney(params) {
  return request({
    url: '/apply/remove',
    method: 'get',
    params: params
  })
}


export function batchremoveMoney(params) {
  return request({
    url: '/apply/batchremove',
    method: 'get',
    params: params
  })
}

export function updateMoney(params) {
  return request({
    url: '/apply/edit',
    method: 'get',
    params: params
  })
}

// export const addUser = params => { return axios.get(`${base}/user/add`, { params: params }) }


