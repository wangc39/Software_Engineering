/*
 * @Author: cnyballk[https://github.com/cnyballk] 
 * @Date: 2018-09-13 11:55:53 
 * @Last Modified by: cnyballk[https://github.com/cnyballk]
 * @Last Modified time: 2018-09-21 12:53:58
 */

var Bmob = require('../../../dist/Bmob.js');
import { registerShareEvent } from '../../../dist/share.js';
var dateTimePicker = require('../../../utils/dateTimePicker.js');


const App = getApp()


const pageOptions = {
  data: {
    focus: false,
    history: [],
    mainBody: '',
    title: '',
    startTime: '',
    endTime: '',
    place: '',
    undertaker: '',
    date: '2018-10-01',
    time1: '12:00',
    dateTimeArray: null,
    dateTime: null,
    dateTimeArray1: null,
    dateTime1: null,
    startYear: 2000,
    endYear: 2050,
    checkEmpty: false
  },
  getMain: function(e){
    this.setData({mainBody:e.detail.value});
  },
  getTitle: function(e){
    this.setData({title:e.detail.value});
  },
  getPlace: function(e){
    this.setData({place: e.detail.value});
  },
  getUndertaker: function(e){
    this.setData({undertaker: e.detail.value});
  },
  handleFocus() {
    this.setData({
      focus: true,
    });
  },
  submitData: function () {
    // 获取到输入的属性数据
    var orderInfo = new Object();
    orderInfo.mainBody = this.data.mainBody;
    orderInfo.title = this.data.title;
    orderInfo.startTime = this.data.startTime
    orderInfo.endTime = this.data.endTime
    orderInfo.place = this.data.place;
    orderInfo.undertaker = this.data.undertaker;

    console.log(this.data.checkEmpty)
    if(orderInfo.mainBody == '' || orderInfo.title == '' ||
        orderInfo.startTime == '' || orderInfo.endTime == '' ||
        orderInfo.place == '' || orderInfo.undertaker == ''){
          this.data.checkEmpty = true;
    }
    else{
      this.data.checkEmpty = false;
    }

    if(orderInfo.endTime > orderInfo.startTime && this.data.checkEmpty == false){
       // 将数据保存到表中，每次点击按钮都会提交一遍
      const query = Bmob.Query('messages1');
      query.set("title", orderInfo.title);
      query.set("mainBody", orderInfo.mainBody);
      query.set("startTime", orderInfo.startTime);
      query.set("endTime", orderInfo.endTime);
      query.set("place", orderInfo.place);
      query.set("undertaker", orderInfo.undertaker);
      query.save().then(res => {
        console.log(res);
        wx.navigateTo({
          url: '../actionList/actionList'
        })
      }).catch(err => {
        console.log(err)
      })
    }
    else if(orderInfo.title == ''){
      //输入有误，利用模态窗口实现弹窗提示
      wx.showModal({
        title: '',
        content: '没有输入标题内容，请检查输入',
        success(res){
          ;
        }
      })
    }
    else if(orderInfo.mainBody == ''){
      //输入有误，利用模态窗口实现弹窗提示
      wx.showModal({
        title: '',
        content: '没有输入正文内容，请检查输入',
        success(res){
          ;
        }
      })
    }
    else if(orderInfo.startTime == ''){
      //输入有误，利用模态窗口实现弹窗提示
      wx.showModal({
        title: '',
        content: '没有修改起始时间，请检查输入',
        success(res){
          ;
        }
      })
    }
    else if(orderInfo.endTime == ''){
      //输入有误，利用模态窗口实现弹窗提示
      wx.showModal({
        title: '',
        content: '没有修改结束时间，请检查输入',
        success(res){
          ;
        }
      })
    }
    else if(orderInfo.endTime <= orderInfo.startTime){
      //输入有误，利用模态窗口实现弹窗提示
      wx.showModal({
        title: '',
        content: '起始时间大于等于结束时间，输入有误',
        success(res){
          ;
        }
      })
    }
    else if(orderInfo.place == ''){
      //输入有误，利用模态窗口实现弹窗提示
      wx.showModal({
        title: '',
        content: '没有输入地点，请检查输入',
        success(res){
          ;
        }
      })
    }
    else{
      //输入有误，利用模态窗口实现弹窗提示
      wx.showModal({
        title: '',
        content: '没有输入举办方，请检查输入',
        success(res){
          ;
        }
      })
    }
   
  },
  onLoad: function(option) {
    // 获取完整的年月日 时分秒，以及默认显示的数组
    var obj = dateTimePicker.dateTimePicker(this.data.startYear, this.data.endYear);
    var obj1 = dateTimePicker.dateTimePicker(this.data.startYear, this.data.endYear);

    // 精确到分的处理，将数组的秒去掉，修改时间选择器后无需再使用
    // var lastArray = obj1.dateTimeArray.pop();
    // var lastTime = obj1.dateTime.pop();

    this.setData({
      dateTime: obj.dateTime,
      dateTimeArray: obj.dateTimeArray,
      dateTimeArray1: obj1.dateTimeArray,
      dateTime1: obj1.dateTime
    });
  },
  history: function() {
    // 进入查看历史信息页面
    wx.navigateTo({
      url: '../actionList/actionList'
    })
  },
  changeDate(e){
    this.setData({ date:e.detail.value});
  },
  changeTime(e){
    // 修改时间
    this.setData({ time1: e.detail.value });
  },
  changeDateTime(e){
    // 设置开始时间
    var arr = e.detail.value;
    var addZeroForHour = '';
    var addZeroForMin = '';
    var addZeroForMonth = '';
    var addZeroForDay = '';
    if(arr[1].toString().length == 1){
      addZeroForMonth = '0';
    }
    if(arr[2].toString().length == 1){
      addZeroForDay = '0'
    }
    if(arr[3].toString().length == 1){
      addZeroForHour = '0';
    }
    if(arr[4].toString().length == 1){
      addZeroForMin = '0'
    }
    console.log((arr[0]+2000).toString()+'年'+
                addZeroForMonth+(arr[1]+1).toString()+'月'+
                addZeroForDay+(arr[2]+1).toString()+'号 '+
                addZeroForHour+(arr[3]).toString()+':'+
                addZeroForMin+(arr[4]).toString());
    this.setData({ 
      dateTime1: e.detail.value,
      startTime: (arr[0]+2000).toString()+'年'+
                 addZeroForMonth+(arr[1]+1).toString()+'月'+
                 addZeroForDay+(arr[2]+1).toString()+'号 '+
                 addZeroForHour+(arr[3]).toString()+':'+
                 addZeroForMin+(arr[4]).toString()
    });
  },
  changeDateTime1(e) {
    // 设置结束时间
    var arr = e.detail.value;
    var addZeroForHour = '';
    var addZeroForMin = '';
    var addZeroForMonth = '';
    var addZeroForDay = '';
    if(arr[1].toString().length == 1){
      addZeroForMonth = '0';
    }
    if(arr[2].toString().length == 1){
      addZeroForDay = '0'
    }
    if(arr[3].toString().length == 1){
      addZeroForHour = '0';
    }
    if(arr[4].toString().length == 1){
      addZeroForMin = '0'
    }
    console.log((arr[0]+2000).toString()+'年'+
                addZeroForMonth+(arr[1]+1).toString()+'月'+
                addZeroForDay+(arr[2]+1).toString()+'号 '+
                addZeroForHour+(arr[3]).toString()+':'+
                addZeroForMin+(arr[4]).toString());
    this.setData({ 
      dateTime1: e.detail.value,
      endTime: (arr[0]+2000).toString()+'年'+
               addZeroForMonth+(arr[1]+1).toString()+'月'+
               addZeroForDay+(arr[2]+1).toString()+'号 '+
               addZeroForHour+(arr[3]).toString()+':'+
               addZeroForMin+(arr[4]).toString()
    });
  },
  changeDateTimeColumn(e){
    // 时间选择器调整
    var arr = this.data.dateTime, dateArr = this.data.dateTimeArray;

    arr[e.detail.column] = e.detail.value;
    dateArr[2] = dateTimePicker.getMonthDay(dateArr[0][arr[0]], dateArr[1][arr[1]]);

    this.setData({
      dateTimeArray: dateArr,
      dateTime: arr
    });
  },
  changeDateTimeColumn1(e) {
    // 时间选择器调整
    var arr = this.data.dateTime1, dateArr = this.data.dateTimeArray1;

    arr[e.detail.column] = e.detail.value;
    dateArr[2] = dateTimePicker.getMonthDay(dateArr[0][arr[0]], dateArr[1][arr[1]]);

    this.setData({
      dateTimeArray1: dateArr,
      dateTime1: arr
    });
  }
}

registerShareEvent(pageOptions);

Page(pageOptions);
