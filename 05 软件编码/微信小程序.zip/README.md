# 云开发 quickstart

-核心代码都在miniprogram/pages里
-首页的代码在person文件夹中，其中add是添加页面，index是树状的的代码，rootList是根节点列表，search是搜索页面，
因为很多地方都用到了这个界面，所以根据功能不同传入不同的参数实现不同的逻辑，upDatePerson是修改页面的
-关系计算的主要逻辑代码在dist/utils里面
-pamphlet是成书页面的代码

-微信小程序每个页面有四种文件,json是代入一些配置的，不用过多关心，WXML是布局的文件的，简单来说
它就是说页面有哪些组件，WXSS通过WXML的class绑定对应得组件然后描述它得布局，比如位置大小，js是
逻辑文件，简单来说就是每个组件点击之后有什么反应，进出页面数据得修改。
如下：
<w-dialog 
    class = "diaglog-show"
    visible="{{ showModal }}"
    bind:onClose="handleClose"
 >这是WXML得一个对话框组件，class定义了它得”名字“，那么在WXSS我们可以找到关于它的描述：
 
.dialog-show{
  background:#4a1b86;
}
意思是这个组件背景是#4a1b86这种颜色的，然后bind:onClose="handleClose"代表的是点击这个
组件的关闭按钮就会运行js文件中的handleClose函数，类似的有bind:bindtap="handleClose"，
bindtap是绑定点击事件

# 活动部分
-活动部分的核心代码在miniprogram/pages/action中
-activity部分负责活动主页面的显示，包括两个部分，分别为消息发布和消息查阅
-消息发布部分的代码逻辑主要由editAction实现
-消息查阅部分代码逻辑由actionDetail和actionList实现，其中actionList负责实现拉取数据库内容并展示
最多10条简易消息列表，actionDetail负责每个具体活动信息内容的显示

## 参考文档

- [云开发文档](https://developers.weixin.qq.com/miniprogram/dev/wxcloud/basis/getting-started.html)

