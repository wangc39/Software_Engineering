/*
 * @Author: Github.Caitingwei[https://github.com/Caitingwei] 
 * @Date: 2018-08-29 17:12:25 
 * @Last Modified by: cnyballk[https://github.com/cnyballk]
 * @Last Modified time: 2018-09-22 11:52:03
 */
var Bmob=require("../../../dist/Bmob.js");

import { registerShareEvent } from '../../../dist/share';

const pageOptions = {
  data: {
    visible: false,
    text: '',
  },
  handleSelected() {
    console.log(...arguments);
  },

  handleVisible() {
    this.setData({ visible: true });
  },
  handleClose() {
    this.setData({ visible: false });
  },
  onLoad: function (options) {
    var that = this;

    // 获取到数据库的消息数据
    // 发布最新的消息通知
    const query = Bmob.Query('messages1');
    query.find().then(res => {
      // console.log(res.length)
      console.log(res[res.length - 1].mainBody)
      that.setData({
        text: '最新通知： ' + res[res.length - 1].mainBody 
              + '  开始时间：' + res[res.length - 1].startTime
              + '  结束时间：' + res[res.length - 1].endTime
              + '  地点：' + res[res.length - 1].place
      })
    });
  },
};

registerShareEvent(pageOptions);

Page(pageOptions);