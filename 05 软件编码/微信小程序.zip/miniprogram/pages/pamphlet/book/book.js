//logs.js
var util = require('../../../utils/util.js')
var touchDot = 0;//触摸时的原点 
var time = 0;// 时间记录，用于滑动时且时间小于1s则执行左右滑动 
var interval = "";// 记录/清理时间记录 
Page({
  data: {
    // logs: []
    scroll_top: 0,
    page_num:0,
    person:null,
    touchStop: true,
    initFontSize:'14',
    open: false,
    nav_list:null,
    colorArr: [{
      value: '#f7eee5',
      name: '米白',
      font: ''
    }, {
      value: '#e9dfc7',
      name: '纸张',
      font: '',
      id: "font_normal"
    }, {
      value: '#a4a4a4',
      name: '浅灰',
      font: ''
    }, {
      value: '#cdefce',
      name: '护眼',
      font: ''
    }, {
      value: '#283548',
      name: '灰蓝',
      font: '#7685a2',
      bottomcolor: '#fff'
    }, {
      value: '#0f1410',
      name: '夜间',
      font: '#4e534f',
      bottomcolor: 'rgba(255,255,255,0.7)',
      id: "font_night"
    }],
    nav:'none',
    ziti:'none',
    _num:1,
    bodyColor:'#e9dfc7',
    daynight:false,
    zj:'none'

  },
  onLoad: function () {
  
    // 本地提取字号大小
    this.setData({
      nav_list:getApp().globalData.dataBmob,
      person:getApp().globalData.dataBmob[0],
    })
    var that = this;
    wx.getStorage({
      key: 'initFontSize',
      success: function (res) {
        // console.log(res.data)
        that.setData({
          initFontSize: res.data
        })
      }
    })
    //存储背景色
    wx.getStorage({
      key: 'bodyColor',
      success: function (res) {
        // console.log(res.data)
        that.setData({
          bodyColor: res.data
        })
      }
    })
    wx.getStorage({
      key: '_num',
      success: function (res) {
        // console.log(res.data)
        that.setData({
          _num: res.data
        })
      }
    })


  },
   //事件处理函数
   //字体变大
  bindBig: function () {
    var that=this;
    if (that.data.initFontSize>20){
      return;
    }
    var FontSize=parseInt(that.data.initFontSize)
    that.setData({
      initFontSize: FontSize +=1
    })
    // console.log(that.data.initFontSize)
    wx.setStorage({
      key: "initFontSize",
      data: that.data.initFontSize
    })
  },
  //字体变小
  bindSmall: function () {
    var that = this;
    if (that.data.initFontSize <12) {
      return;
    }
    var FontSize = parseInt(that.data.initFontSize)
    that.setData({
      initFontSize: FontSize -= 1
    })
    // console.log(that.data.initFontSize)
    wx.setStorage({
      key: "initFontSize",
      data: that.data.initFontSize
    })
  },
  //点击中间区域显示底部导航
  midaction:function(){
    if(this.data.open){
      this.setData({
        open:false
      })
      return
    }
   
    if (this.data.nav=='none'){
      this.setData({
        nav:'block'
      })
    }else{
      this.setData({
        nav: 'none',
        ziti: 'none'
      })

    }
  },
  //点击字体出现窗口
  zitiaction:function(){
    if (this.data.ziti == 'none') {
      this.setData({
        ziti: 'block'
      })
    } else {
      this.setData({
        ziti: 'none'
      })
    }
  },
  //选择背景色
  bgChange:function(e){
    // console.log(e.target.dataset.num)
    // console.log(e)
    this.setData({
      _num: e.target.dataset.num,
      bodyColor: this.data.colorArr[e.target.dataset.num].value
    })
    wx.setStorage({
      key: "bodyColor",
      data: this.data.colorArr[e.target.dataset.num].value
    })
    wx.setStorage({
      key: "_num",
      data: e.target.dataset.num
    })
  },

  //滚动隐藏窗口
  scrollContain:function(){
    this.setData({
      nav: 'none',
      ziti: 'none',
      zj:'none'
    })
  },
  //滚动到底部
  bindscrolltolower:function(){
    this.setData({
      zj: 'block',
    })
  },
  //上一页下一页
  lastPage:function(){
    console.log(this.data.page_num)
    let index = this.data.page_num;
    if(index != 0)
      this.setData({
        page_num:index - 1,
        person: this.data.nav_list[index -1],

        scroll_top: 0
      })
  },
  nextPage:function(){
    // console.log(getApp().globalData.dataBmob.length)
    console.log(this.data.page_num)
    let index = this.data.page_num;
    if(index <= (this.data.nav_list.length -1))
      this.setData({
        page_num: index + 1,
        person:  this.data.nav_list[index +1],
        
        scroll_top: 0
      })
  },
  // 触摸开始事件 
  touchStart: function (e) {
    console.log("sdfs")
    this.setData({
      touchStop: false,
    })
    touchDot = e.touches[0].pageX; // 获取触摸时的原点 
    // 使用js计时器记录时间  
    interval = setInterval(function () {
      time++;
    }, 100);
  },
  // 触摸移动事件 
  touchMove: function (e) {
    var touchMove = e.touches[0].pageX;
    // console.log("touchMove:" + touchMove + " touchDot:" + touchDot + " diff:" + (touchMove - touchDot));
    // 向左滑动  
    if(this.data.touchStop)return
    if (touchMove - touchDot <= -70 && time < 10) {

      this.nextPage();
      this.setData({
        touchStop:true
      })

    }
    // 向右滑动 
    if (touchMove - touchDot >= 70 && time < 10) {

      this.lastPage();
      this.setData({
        touchStop:true
      })

    }
    // console.log(this.data.person)
  },
  // 触摸结束事件 
  touchEnd: function (e) {
    clearInterval(interval); // 清除setInterval 
    time = 0;
  },
   //左侧导航的开关函数
  off_canvas: function(){
    this.setData({nav:'none'});
    this.data.open ? this.setData({open: false}) :this.setData({open: true});
  },
   //列表的操作函数
 open_list: function(opts){  
   var index = Number(opts.currentTarget.id);
   
  this.setData({ person: this.data.nav_list[index],page_num: index,open:false,scroll_top: 0,touchStop:false});
  console.log(this.data.page_num)
  time = 0;
 },
})