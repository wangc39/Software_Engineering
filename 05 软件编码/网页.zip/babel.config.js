module.exports = {
  presets: [
    '@vue/app'
  ],
  // publicPath:'./',
  sourceType: 'unambiguous'
}
