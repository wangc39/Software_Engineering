import Vue from 'vue'
import App from './App'
import router from './router'
import store from './store/'
// 'development',use package;'production':use cdn;
import ElementUI from 'element-ui'
Vue.use(ElementUI, { size: 'mini'});
import('element-ui/lib/theme-chalk/index.css')

import './components/iconSvg' // iconSvg

import '@/permission' // permission control

import '@/mockjs'; // mock数据

import i18n from "@/lang";


Vue.config.productionTip = false;



new Vue({
  router,
  store,
  i18n,  
  render: h => h(App),
}).$mount('#app')
