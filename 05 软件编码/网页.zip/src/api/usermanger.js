import request from '@/utils/axios'

export function getMoneyIncomePay(params) {
  return request({
    url: '/usermanger/get',
    method: 'get',
    params: params
  })
}

export function addMoney(params) {
  return request({
    url: '/usermanger/add',
    method: 'get',
    params: params
  })
}

export function removeMoney(params) {
  return request({
    url: '/usermanger/remove',
    method: 'get',
    params: params
  })
}


export function batchremoveMoney(params) {
  return request({
    url: '/usermanger/batchremove',
    method: 'get',
    params: params
  })
}

export function updateMoney(params) {
  return request({
    url: '/usermanger/edit',
    method: 'get',
    params: params
  })
}

// export const addUser = params => { return axios.get(`${base}/user/add`, { params: params }) }


