import Mock from 'mockjs'

import * as mUtils from '@/utils/mUtils'
import Bmob from '../dist/Bmob-2.2.5.min.js'

Bmob.initialize("f5548270aaba8ebe","674436")
// Vue.prototype.Bmob = Bmob
let List = []
const count = 1000
const query = Bmob.Query("messages1");
query.find().then(res => {
  console.log(res[0])
  List = JSON.parse(JSON.stringify(res)); 
  List.reverse();
});

export default {

  getMoneyList: config => {
    const { name, page = 1, limit = 20 } = mUtils.param2Obj(config.url)
    const query = Bmob.Query("messages1");
    query.find().then(res => {
      console.log(res[0])
      List = JSON.parse(JSON.stringify(res)); 
    });
    const mockList = List.filter(user => {
      if (name && user.username.indexOf(name) === -1) return false
      return true
    })

    const pageList = mockList.filter((item, index) => index < limit * page && index >= limit * (page - 1))
    return {
      code: 200,
      data: {
        total: mockList.length,
        moneyList: pageList
      }
    }
  },
 
  createMoney: config => {
    const { objectId, title, undertaker, mainBody, place} = mUtils.param2Obj(config.url)
    List.unshift({
      objectId:objectId,
      id: Mock.Random.guid(),
      title: title,
      undertaker: undertaker,
      mainBody:mainBody,
      place: place,

    })
    const query = Bmob.Query("messages1");
    query.find().then(res => {
      console.log(res[0])
      List = JSON.parse(JSON.stringify(res)); 
      List.reverse();
    });
    return {
      code: 200,
      data: {
        message: '添加成功'
      }
    }
  },
  /**
   * 删除用户
   * @param id
   * @return {*}
   */
  deleteMoney: config => {
    const { objectId } = mUtils.param2Obj(config.url)
    if (!objectId) {
      return {
        code: -999,
        message: '参数不正确'
      }
    } else {
      List = List.filter(u => u.objectId !== objectId)
      List.reverse()
      return {
        code: 200,
        data: {
          message: '删除成功'
        }
      }
    }
  },
  /**
   * 批量删除
   * @param config
   * @return {{code: number, data: {message: string}}}
   */
  batchremoveMoney: config => {
    // objectIds = objectIds.split(',')
    const { objectIds } = mUtils.param2Obj(config.url)
    console.log(config)
    let newids = objectIds.split(',')
    var j
    for(j = 0; j < newids.length; j ++){
      List = List.filter(u => (u.objectId !== newids[j]))
    }
    List.reverse()
    //List = List.filter(u => !config.includes(u.objectId))
    return {
      code: 200,
      data: {
        message: '批量删除成功'
      }
    }
  },
  /**
   * 修改用户
   * @param id, name, addr, age, birth, sex
   * @return {{code: number, data: {message: string}}}
   */
  updateMoney: config => {
    const { objectId,undertaker, mainBody, title, place } = mUtils.param2Obj(config.url)
    List.some(u => {
      if (u.objectId === objectId) {
        const query = Bmob.Query('messages1');
        query.get(objectId).then(res => {
          console.log(res)
          res.set('undertaker',undertaker)
          res.set('mainBody', mainBody)
          res.set('title', title)
          res.set('place', place)
          res.save()
        }).catch(err => {
          console.log(err)
        })
        u.undertaker = undertaker
        u.mainBody = mainBody
        u.title = title
        u.place = place
        return true
      }
    })
    List.reverse()
    return {
      code: 200,
      data: {
        message: '编辑成功'
      }
    }
  }
}