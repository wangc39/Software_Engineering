import Mock from 'mockjs'

import * as mUtils from '@/utils/mUtils'
import Bmob from '../dist/Bmob-2.2.5.min.js'

Bmob.initialize("f5548270aaba8ebe","674436")
// Vue.prototype.Bmob = Bmob
let List = []
const count = 1000
const query = Bmob.Query("apply");
query.find().then(res => {
  console.log(res)
  List = JSON.parse(JSON.stringify(res)); 
  var i;
  for(i = 0; i < List.length; i ++){
    if(List[i].hasOwnProperty("UpdateMsg")){
      List[i].UpdateMsg = JSON.stringify(List[i].UpdateMsg);
    }
    else{
      List[i].UpdateMsg = "";
    }
  }
  List = List.filter(u => (!u.hasOwnProperty('state')))
});
function destory(objectId){
  const query = Bmob.Query('Person');
  query.get(objectId).then(res => {
    let ccList = []
    if(res.hasOwnProperty('children')){
      ccList = JSON.parse(JSON.stringify(res.children)); 
    }

    if(res.father_name || res.level > 0){
      const fquery = Bmob.Query("Person");
      fquery.equalTo("username", '==', res.father_name);
      fquery.equalTo("birthday", '==', res.father_bir);
      fquery.find().then(fres => {
        if(fres.length > 0){
          const ffquery = Bmob.Query('Person');
          ffquery.get(fres[0].objectId).then(ffres => {
            let cList = []
            cList = JSON.parse(JSON.stringify(ffres.children)); 
            cList = cList.filter(u => u.objectId !== objectId)
            ffres.set('children', cList)
            ffres.save()
          }).catch(err => {
            console.log(err)
          })
        }
        console.log(fres)
      });
    }
    if(res.level == 0){
      const branquery = Bmob.Query("Branch");
      branquery.equalTo("personid","==", objectId);
      branquery.find().then(branres => {
        const desquery = Bmob.Query('Branch');
        desquery.destroy(branres[0].objectId).then(desres => {
          console.log(desres)
        }).catch(err => {
          console.log(err)
        })
      });
    }
    if(res.wife){
      const query = Bmob.Query('Person');
      query.destroy(res.wife).then(wres => {
        console.log(wres)
      }).catch(err => {
        console.log(err)
      })
    }
    console.log(ccList)
    var i;
      for(i = 0; i < ccList.length; i ++){
        console.log(i)
        destory(ccList[i])
      }
    
  }).catch(err => {
    console.log(err)
  })
  const dquery = Bmob.Query('Person');
  dquery.destroy(objectId).then(wres => {
    console.log(wres)
  }).catch(err => {
    console.log(err)
  })
}
// let List = []
// const count = 60
// let typelist = [1, 2, 3, 4, 5, 6, 7, 8]

// for (let i = 0; i < count; i++) {
//   List.push(Mock.mock({
//     objectId: Mock.Random.guid(),
//     username: Mock.Random.cname(),
//     createTime: Mock.Random.datetime(),
//     birthday: Mock.Random.datetime(),
//     'gender|1': typelist，
//     father_name: Mock.Random.cname(),
//     wife_name: Mock.Random.datetime(),
//   }))
// }

export default {
  /**
   * 获取列表
   * 要带参数 name, page, limt; name可以不填, page,limit有默认值。
   * @param name, page, limit
   * @return {{code: number, count: number, data: *[]}}
   */
  getMoneyList: config => {
    const { name, page = 1, limit = 20 } = mUtils.param2Obj(config.url)

    const mockList = List.filter(user => {
      if (name && user.username.indexOf(name) === -1) return false
      return true
    })
    const pageList = mockList.filter((item, index) => index < limit * page && index >= limit * (page - 1))
    return {
      code: 200,
      data: {
        total: mockList.length,
        moneyList: pageList
      }
    }
  },
 
  createMoney: config => {
    const { objectId, Node1,  operation, updateMsg} = mUtils.param2Obj(config.url)
    List.unshift({
      id: Mock.Random.guid(),
      objectId:objectId,
      operation: operation,
      Node1: Node1,
      updateMsg:updateMsg,

    })
    return {
      code: 200,
      data: {
        message: '添加成功'
      }
    }
  },
  /**
   * 删除用户
   * @param id
   * @return {*}
   */
  deleteMoney: config => {
    const { objectId } = mUtils.param2Obj(config.url)
    if (!objectId) {
      return {
        code: -999,
        message: '参数不正确'
      }
    } else {
      List = List.filter(u => u.objectId !== objectId)

      return {
        code: 200,
        data: {
          message: '删除成功'
        }
      }
    }
  },
  /**
   * 批量删除
   * @param config
   * @return {{code: number, data: {message: string}}}
   */
  batchremoveMoney: config => {
    // objectIds = objectIds.split(',')
    const { objectIds } = mUtils.param2Obj(config.url)
    console.log(config)
    let newids = objectIds.split(',')
    var j
    for(j = 0; j < newids.length; j ++){
      List = List.filter(u => (u.objectId !== newids[j]))
    }
    //List = List.filter(u => !config.includes(u.objectId))
    return {
      code: 200,
      data: {
        message: '批量删除成功'
      }
    }
  },
  /**
   * 修改用户
   * @param id, name, addr, age, birth, sex
   * @return {{code: number, data: {message: string}}}
   */
  updateMoney: config => {
    const { objectId, operation } = mUtils.param2Obj(config.url)
    console.log(objectId)
    console.log(operation)
    List.some(u => {
      if (u.objectId === objectId) {
        const query = Bmob.Query('apply');
        query.get(objectId).then(res => {
          if(res.hasOwnProperty('state')){
            return {
              code: 200,
              data: {
                message: '此前已经通过或否决该申请'
              }
            }
          }
          else if(operation == 0){
            //添加节点
                        // add
                        var myid;
                        const pquery = Bmob.Query('Person');
                        pquery.set("username",(res.UpdateMsg).username)
                        pquery.set("birthday",(res.UpdateMsg).birthday)
                        pquery.set("gender", (res.UpdateMsg).gender[0])

                        if(res.hasOwnProperty('wife_name')){
                            pquery.set('is_wife', '1')
                        }
                        else{
                            pquery.set('is_wife', '0')
                        }

                        if(res.hasOwnProperty('wife_name')){
                          const wquery = Bmob.Query('Person');
                          wquery.get(res.Node1).then(wres => {
                            pquery.set('level', wres.level)
                            pquery.set('wife_name', wres.username)
                            pquery.set('wife_bir', wres.birthday)
                            pquery.save().then(pres => {
                              console.log(pres)
                            }).catch(err => {
                              console.log(err)
                            })
                          }).catch(err => {
                            console.log(err)
                          })
                        } 
                        else if(res.hasOwnProperty('father_name')){
                          const fquery = Bmob.Query('Person');
                          fquery.get(res.Node1).then(fres => {
                            pquery.set('level', fres.level+1)
                            pquery.set('father_name', fres.username)
                            pquery.set('father_bir', fres.birthday)
                            pquery.save().then(pres => {
                              const ffquery = Bmob.Query('Person');
                              ffquery.get(res.Node1).then(ffres => {
                                let cList = []
                                if(ffres.hasOwnProperty('children')){
                                cList = JSON.parse(JSON.stringify(ffres.children)); 
                                cList.push(pres.objectId)
                                }
                                else{
                                    cList.push(pres.objectId)
                                }
                                ffres.set('children',cList)
                                ffres.save()
                              }).catch(err => {
                                console.log(err)
                              })
                            }).catch(err => {
                              console.log(err)
                            })
                          }).catch(err => {
                            console.log(err)
                          })


                        }    
                        else{
                          //pass
                          var a;
                        }                   
          }
          else if(operation == 1){
            //删除节点
            destory(res.Node1)
          }
          else if(operation == 2){
            //编辑本身信息
            const pquery = Bmob.Query('Person');
            pquery.get(res.Node1).then(pres => {
              if((res.UpdateMsg).hasOwnProperty('username')){
                pres.set('username', (res.UpdateMsg).username)
              }
              if(res.UpdateMsg.hasOwnProperty('birthday')){
                pres.set('birthday', (res.UpdateMsg).birthday)
              }
              if(res.UpdateMsg.hasOwnProperty('gender')){
                pres.set('gender', (res.UpdateMsg).gender)
              }
              pres.save()
            }).catch(err => {
              console.log(err)
            })

          }
        
        }).catch(err => {
          console.log(err)
        })
        const aquery = Bmob.Query('apply');
        aquery.get(objectId).then(res => {
          res.set('state','通过')
          res.save()
        }).catch(err => {
          console.log(err)
        })
        return true
      }
    })
    return {
      code: 200,
      data: {
        message: '编辑成功'
      }
    }
  }
}