// import { string } from 'yargs';
//index.js
import { Loading, Toast } from '../../../dist/index';
const WxNotificationCenter = require("../../../config/WxNotificationCenter");
import {getObjectById} from '../../../dist/util';
var wayIndex = -1;
var school_area = '';
var grade = '';
// 当联想词数量较多，使列表高度超过340rpx，那设置style的height属性为340rpx，小于340rpx的不设置height，由联想词列表自身填充
// 结合上面wxml的<scroll-view>
var arrayHeight = 0;

Page({
  data: {
    label:"",
    option: {icon:"search"},
    inputValue: '', //点击结果项之后替换到文本框的值
    adapterSource:null,
    // adapterSource: ["weixin", "wechat", "android", "Android", "IOS", "java", "javascript", "微信小程序", "微信公众号", "微信开发者工具"], //本地匹配源
    bindSource: [], //绑定到页面的数据，根据用户输入动态变化
    indexList:[],
    hideScroll: true,
  },
  onLoad:function(options){
    // console.log(options.node);
    this.setData({
      label: options.node,
      adapterSource: getApp().globalData.dataBmob,
    })
  },
  //当键盘输入时，触发input事件
  searchList: function (e) {
    //用户实时输入值
    var prefix = e.detail.value
    //匹配的结果
    var newSource = []
    var indexs = []
    var i = 0;
    if (prefix != "") { 
      // 对于数组array进行遍历，功能函数中的参数 `e`就是遍历时的数组元素值。
      this.data.adapterSource.forEach(function (e) { 
        // 用户输入的字符串如果在数组中某个元素中出现，将该元素存到newSource中
        if (e.username.indexOf(prefix) != -1) {
          // console.log(e);
          var person = e;
          person.index = i;
          indexs.push(i);
          newSource.push(person)
        }
        i += 1;
      })
    };
    // 如果匹配结果存在，那么将其返回，相反则返回空数组
    if (newSource.length != 0) {
      this.setData({
        // 匹配结果存在，显示自动联想词下拉列表
        hideScroll: false,
        bindSource: newSource,
        indexList:indexs,
        arrayHeight: newSource.length * 271
      })
    } else {
      this.setData({
        // 匹配无结果，不现实下拉列表
        hideScroll: true,
        bindSource: [],
        indexList:[]
      })
    }
  },
  cancelsearch:function(e){
    // console.log("德国撒");
    this.setData({
      hiddScroll:true,
      bindSource: [],
      indexList:[],
    })
  },
  endsearchList:function(e){
    
    if(e.detail.value == "")
      return;
    let that = this;
    Loading.show({
      hide:() =>{
        Toast.show({
          position:"bottom",
          message:"搜索成功"
        })

      },
      
    });

    //用户实时输入值
    var prefix = e.detail.value
    //匹配的结果
    var newSource = this.data.bindSource;
    var indexs = this.data.indexList;
    console.log(newSource);
    var i = 0;
    if (prefix != "") { 
      // 对于数组array进行遍历，功能函数中的参数 `e`就是遍历时的数组元素值。
      this.data.adapterSource.forEach(function (e) { 
        // 用户输入的字符串如果在数组中某个元素中出现，将该元素存到newSource中
        let Match = false;
        if(indexs.indexOf(i) == -1){
          for(let j = 0;j < prefix.length;j++){
            if(e.username.indexOf(prefix[j]) != -1)
              Match = true;
          }
        }
        // prefix.forEach(function(e){
        //   if (e.username.indexOf(prefix) != -1) {
        //   // console.log(e);
        //     Match = true;
        //   }
        // });
        if(Match){
          var person = e;
          person.index = i;
          newSource.push(person)
        }
        i += 1;
      })
    };
    // 如果匹配结果存在，那么将其返回，相反则返回空数组
    if (newSource.length != 0) {
      this.setData({
        // 匹配结果存在，显示自动联想词下拉列表
        hideScroll: false,
        bindSource: newSource,
        indexList:indexs,
        arrayHeight: newSource.length * 271
      })
    } else {
      this.setData({
        // 匹配无结果，不现实下拉列表
        hideScroll: true,
        indexList:[],
        bindSource: []
      })
    }
    Loading.hide();
    
  },
  // 用户点击选择某个联想字符串时，获取该联想词，并清空提醒联想词数组
  itemtap: function (e) {
    // console.log(this.data.bindSource[e.currentTarget.dataset.index]);
    if(this.data.label == "start"){
      getApp().globalData.startNode = this.data.bindSource[e.currentTarget.dataset.index];
      wx.switchTab({
        url: '../index/index',
      })
    }else if(this.data.label == "end"){
      getApp().globalData.endNode = this.data.bindSource[e.currentTarget.dataset.index];
      wx.switchTab({
        url: '../index/index',
      })
    }else if(this.data.label == "match"){
      var person = this.data.bindSource[e.currentTarget.dataset.index];
      wx.getStorage({
        key: 'userInfo',
        success:function(res){

          getApp().globalData.dataBmob[person.index].isBind = true;
          getApp().globalData.dataBmob[person.index].thumb = res.data.avatarUrl;
          getApp().globalData.selfNode = getApp().globalData.dataBmob[person.index];
        }
      })

      this.storePersonData(person);
      wx.switchTab({
        url: '../../home/mine/mine',
      })
    }
    else{
      getApp().globalData.currentNode = this.data.bindSource[e.currentTarget.dataset.index];
      wx.switchTab({
        url: '../index/index'
      })
    }
    
    // this.setData({
    //   // .id在wxml中被赋值为{{item}}，即当前遍历的元素值
    //   inputValue: this.data.bindSource[e.currentTarget.dataset.index].username,
    //   // 当用户选择某个联想词，隐藏下拉列表
    //   hideScroll: true,
    //   bindSource: []
    // })
  },
  storePersonData(detail){

    // 将提交的信息 存储为缓存变量
    try {
      wx.setStorage({
        data: detail,
        key: 'person',
      })
    } catch (e)
    {
      console.log("存储个人信息失败")
      console.log(e)
    }
  },
})