
var Bmob = require('../../../dist/Bmob.js');
import { registerShareEvent } from '../../../dist/share.js';

const pageOptions = {

  /**
   * 页面的初始数据
   */
  data: {
    loading: false,
    focus: false,
    history: [],
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    var that = this;
    let arr = [];
    var temp = 0;

    // 获取到数据库的消息数据
    const query = Bmob.Query('messages1');
    query.find().then(res => {
      console.log(res.length)
      if(res.length >= 10){
        temp = 10;
      }
      else{
        temp = res.length;
      }
      for(var i = res.length - 1; i >= res.length - temp; i--){
        arr.push(res[i])
        console.log(res[i])
      }
      that.setData({
        history: arr
      })
    });
  },
  Click(e){
    console.log(this.data.history[Number(e.currentTarget.id)]);
    wx.navigateTo({
      url: '../actionDetail/actionDetail?item= ' + JSON.stringify(this.data.history[Number(e.currentTarget.id)]),
    })
  },
  handleChange(e) {
    this.setData({
      loading: e.detail.value,
    })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
};

registerShareEvent(pageOptions);

Page(pageOptions);