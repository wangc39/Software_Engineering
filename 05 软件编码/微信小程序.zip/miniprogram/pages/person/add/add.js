// miniprogram/pages/updatePerson.js
import { Toast } from '../../../dist/index.js';
var Bmob=require("../../../dist/Bmob.js");

Page({

  /**
   * 页面的初始数据
   */
  data: {
    default_date:null,
    date:"2019-01-01",
    person:null,
    textarea_visible: true,
    userNameRules: {
     
      maxLength: {
        value: 6,
        message: '姓名最多6个字',
      },
      minLength: {
        value: 2,
        message: '姓名最少两个字',
      },
    },
    isRequired: {
      required: {
        value: true,
        message: '必填',
      },
    },
    levelRules:{
      range: {
        value: [0,300],
        message: "辈分应该小于三百且为正整数",
      },
    }

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      // date:"1975-1-4",
      person: JSON.parse(options.Person),
      default_date: JSON.parse(options.Person).birthday
      
    })

    console.log(this.data.default_date);
  },
  handlePickerOpen() {
    this.setData({ textarea_visible: true })
  },
  selectRelation(event){
    var birth_father = Number(this.data.person.birthday.split("-")[0]);
    let y;
    if(event.detail.value[0] == "子女"){
      y = String(birth_father+12)+"-1-1";
    }else{
      y = String(birth_father)+"-1-1";
    }

    this.setData({ textarea_visible: false,default_date:this.data.person.birthday})
  },
  handlePickerCancel(event) {
    
    this.setData({ textarea_visible: false})
  },
  updatePersonCnfirm(event){
    if(this.data.person.gender == '女' && event.detail.relation == "配偶"){
      Toast.show({
        position: 'bottom',
        message: "暂不支持入赘"
      })
      return
    }
    if(event.detail.relation == "配偶" && event.detail.gender == '男'){
      Toast.show({
        position: 'bottom',
        message: "暂不支持同性结婚"
      })
      return
    }
    
   
    
    // var nodeInit = Bmob.Query("Person");
    var personToAdd;
    if(this.data.person.is_wife == "0"){
      personToAdd = this.data.person;
    }else{
      personToAdd = getApp().globalData.dataBmob[this.data.person.husband_index];
    }
    if(event.detail.relation == "子女" ){
      var birth_year = Number(event.detail.birthday.getFullYear());
      var birth_father = Number(personToAdd.birthday.split("-")[0]);
      var diff_year = birth_year - birth_father;
      if(diff_year < 10){
        Toast.show({
          position: 'bottom',
          message: "男性最小可生育年龄在12-14岁，请认真填写"
        })
        return
      }
     
    }
    // nodeInit.set("id",personToAdd.objectId);
    var UpdateMsg = new Object();
    var appendNode = Bmob.Query("apply");
    
    if(event.detail.username){
      UpdateMsg.username = event.detail.username;
      // appendNode.set("username",event.detail.username);
    };
    if(event.detail.gender[0]){
      UpdateMsg.gender = event.detail.gender;
      // appendNode.set("gender",event.detail.gender[0]);
    };
    if(event.detail.birthday != ""){
      var s = event.detail.birthday;
      // appendNode.set("birthday",String(s.getFullYear()) +"-"+ String(s.getMonth()+1) + "-"+String(s.getDate()));
      UpdateMsg.birthday = String(s.getFullYear()) +"-"+ String(s.getMonth()+1) + "-"+String(s.getDate());
    };
    if(event.detail.relation == "子女"){
      // appendNode.set("father",personToAdd.objectId);
      // appendNode.set("is_wife","0");
      // appendNode.set("level",personToAdd.level+1);
      UpdateMsg.is_wife = "0";
      UpdateMsg.level = personToAdd.level+1;
      appendNode.set("father_name",personToAdd.username);
      appendNode.set("father_birthday",personToAdd.birthday);
    }else{
      // appendNode.set("is_wife","1");
      // appendNode.set("level",personToAdd.level);
      UpdateMsg.is_wife = "1";
      UpdateMsg.level = personToAdd.level;
      appendNode.set("wife_name",personToAdd.username);
      appendNode.set("wife_birthday",personToAdd.birthday);
    }
    appendNode.set("operation",0);
    appendNode.set("Node1",personToAdd.objectId);
    appendNode.set("UpdateMsg",UpdateMsg);
    appendNode.set("Relation",event.detail.relation);


    
    appendNode.save().then(appendRes=>{
      Toast.show({
        message:"申请已提交",
        position:"bottom"
      })
        // if(event.detail.relation == "子女"){

        //   // console.log(appendRes.objectId);
        //   if(personToAdd.children){
        //     let childrens = personToAdd.children;
        //     childrens.push(appendRes.objectId)
            
        //     nodeInit.set("children",childrens);
        //   }
        //   else{nodeInit.set("children",[appendRes.objectId]);}
        // }else{
        //   nodeInit.set("wife",appendRes.objectId);
        // };
        // nodeInit.save().then(res=>{console.log("succes")}).catch(error=>{console.log(error)});
        // getApp().globalData.is_fresh = true;
        wx.switchTab({
          url: "../index/index",
        });
      }).catch(error=>{
        console.log(error);
      })
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})