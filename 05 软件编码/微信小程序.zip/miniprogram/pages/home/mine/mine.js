import { ActionSheet } from '../../../dist/index';
import { Loading, Toast } from '../../../dist/index';
import {cal_relation,getObjectById} from '../../../dist/util';
var Bmob=require("../../../dist/Bmob.js");
// index.js

// 获取应用实例
const app = getApp()

Page({
  data: {
    
    identify: "普通成员",
    person: undefined,
    userInfo: {},
    hasUserInfo: false,
    canIUse: wx.canIUse('button.open-type.getUserInfo'),
    canIUseGetUserProfile: false,
    canIUseOpenData: wx.canIUse('open-data.type.userAvatarUrl') && wx.canIUse('open-data.type.userNickName'), // 如需尝试获取用户信息可改为false
    items2: [
      {
        text: '分享给朋友',
        type: 'share',
        icon: 'forward-o',
        openType: 'share',
      },
      {
        text: '分享到朋友圈',
        type: 'shareTimeLine',
        icon: 'share',
        openType: 'share',
      },
    ],
  },

  handleClick(e) {
    const key = e.currentTarget.dataset.key;
    const item = e.detail;
    if(item.type === 'hide') return ActionSheet.hide({});
    if (key == 6) {
      this.setData(
        {
          [`items${key}[${item.key}].loading`]: true,
        },
        () => {
          setTimeout(() => {
            this.setData({
              [`items${key}[${item.key}].loading`]: false,
              [`visible${key}`]: false,
            });
          }, 2000);
        }
      );
    } else {
      this.setData({
        [`visible${key}`]: false,
      });
    }
  },

  // 实现跳转填写信息的界面
  myShowModal:function(options){
    wx.showModal({
      cancelColor: 'cancelColor',
      title: "提示",
      showCancel: false,
      content: "请先完善个人信息",
      success(res){
        if(res.confirm){
          console.log("用户点击确定")
          wx.navigateTo({
            url: '/pages/person/search/search?node=match',
            success: function (res) {
              console.log("成功跳转到别的界面中")
            },
            fail(e)
            {
              console.log("跳转失败")
              console.log(e)
            }
          })
        }
      }
    })
  },

  onLoad() {
    let that = this;
    if (wx.getUserProfile) {
      that.setData({
        canIUseGetUserProfile: true
      })
    }
    
    wx.getStorage({
      key: 'userInfo',
      success: function(e){
        console.log(e.data.avatarUrl)
        if(e.data.avatarUrl){
          that.setData({
            hasUserInfo:true,
            userInfo:e.data
          })
          var node = Bmob.Query("Person");
          Loading.show({
            hide:()=>{
            },
            
          })
          node.find().then(res=>{
            getApp().globalData.dataBmob = res;
            
            var branch = Bmob.Query("Branch");
            branch.find().then(resBranch=>{
              let resBrachArray = [];
              for(let j = 0;j < resBranch.length;j++){
                var result,person,index;
                // 找出根对应的人的信息
                result = getObjectById(resBranch[j].personid,res);
                person = result.person;
                index = result.index;
                resBrachArray.push(index);
              }
              getApp().globalData.dataBranch = resBrachArray;
              console.log(getApp().globalData.dataBranch);
              console.log(res)
              Loading.hide();
            }).catch(error=>{console.log(error)});
            // 第一次就直接跳转到填写完整信息的界面
            wx.getStorage({
              key: 'person',
              success (res) {
                // console.log("person data: ", res.data)
                console.log("这里是getStorage函数")
                console.log(res.data)
                if(res.data.objectId){
                  for(let i = 0;i < getApp().globalData.dataBmob.length;i++){
                    if(res.data.objectId == getApp().globalData.dataBmob[i].objectId){
                      getApp().globalData.dataBmob[i].isBind = true;
                      getApp().globalData.dataBmob[i].thumb = that.data.userInfo.avatarUrl;
                      getApp().globalData.selfNode = getApp().globalData.dataBmob[i];
                      break;
                    }
                    
                  }
                  that.setData({
                  person: res.data
                  })
                  // console.log(that.data.userInfo);
                  
                }else{

                  that.myShowModal();
                }
                
              },
              fail(res) {
                console.log("返回数据失败");
                // 实现信息窗口提示，跳转到填写信息的界面
                that.myShowModal();
              }
            })
            
        }).catch(error=>{console.log(error)});
        }
        
      }
    })


  },

  getUserProfile(e) {
    let that = this;
    // 推荐使用wx.getUserProfile获取用户信息，开发者每次通过该接口获取用户个人信息均需用户确认，开发者妥善保管用户快速填写的头像昵称，避免重复弹窗
    wx.getUserProfile({
      desc: '用于获取头像和昵称可视化', // 声明获取用户个人信息后的用途，后续会展示在弹窗中，请谨慎填写
      success: (res) => {
        console.log("success")
        console.log(res)
        this.setData({
          userInfo: res.userInfo,
          hasUserInfo: true
        })
        try{
          wx.setStorage({
            data: res.userInfo,
            key: 'userInfo',
          })
        }catch(error){
          console.log("error")
          console.log(error)
        }
        that.onLoad();
      },
      fail: (error)=>{
        console.log(error);
      }
    })
    
  },
  getUserInfo(e) {
    // 不推荐使用getUserInfo获取用户信息，预计自2021年4月13日起，getUserInfo将不再弹出弹窗，并直接返回匿名的用户个人信息
    // console.log(e)
    this.setData({
      userInfo: e.detail.userInfo,
      hasUserInfo: true
    })
  },
  handleShow:function(){
    wx.getStorage({
      key: 'userInfo',
      success:function(e){
        console.log(e)
      }
    })
    wx.setStorage({
      data: new Object(),
      key: 'userInfo',
    })
    wx.setStorage({
      data: new Object(),
      key: 'person',
    })
    this.setData({
      userInfo: {},
      hasUserInfo: false,
    })
    getApp().globalData.selfNode = {};
    this.onLoad();

  }
  
})
