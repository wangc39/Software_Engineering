// miniprogram/pages/updatePerson.js
var Bmob=require("../../../dist/Bmob.js");
import {Toast } from '../../../dist/index';
Page({

  /**
   * 页面的初始数据
   */
  data: {
    person:null,
    textarea_visible: true,
    userNameRules: {
     
      maxLength: {
        value: 6,
        message: '姓名最多6个字',
      },
      // minLength: {
      //   value: 3,
      //   message: '姓名最少三个字',
      // },
    },
    isRequired: {
      // required: {
      //   value: true,
      //   message: '必填',
      // },
    },
    levelRules:{
      range: {
        value: [0,300],
        message: "辈分应该小于三百且为正整数",
      },
    }

  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    this.setData({
      person: JSON.parse(options.Person)
    })

    console.log(this.data.person);
  },
  handlePickerOpen() {
    this.setData({ textarea_visible: true })
  },
  handlePickerCancel() {
    this.setData({ textarea_visible: false })
  },
  updatePersonCnfirm(event){
    // console.log(event.detail);
    var appl = Bmob.Query("apply");
    // var node = Bmob.Query("Person");
    var node = new Object();
    appl.set("Node1",this.data.person.objectId);
    if(event.detail.username){
      // node.set("username",event.detail.username);
      node.username = event.detail.username;
    }else{
      node.username = this.data.person.username;
    };
    if(event.detail.gender[0]){
      node.gender = event.detail.gender[0];
      // node.set("gender",event.detail.gender[0]);
    };
    if(event.detail.birthday != "" && event.detail.birthday != null){
      // console.log(event.detail.birthday)
      var s = event.detail.birthday;
      // node.set("birthday",String(s.getFullYear()) +"-"+ String(s.getMonth()+1) + "-"+String(s.getDate()));
      node.birthday = String(s.getFullYear()) +"-"+ String(s.getMonth()+1) + "-"+String(s.getDate());
    };
    // if(event.detail.level){
    //   node.set("level",Number(event.detail.level));
    // };
    appl.set("UpdateMsg",node);
    appl.set("operation",2);
    if (this.data.person.wife_index){
      let wife = getApp().globalData.dataBmob[this.data.person.wife_index];
      appl.set("wife_name",wife.username);
      appl.set("wife_birthday",wife.birthday);
    }
    if (this.data.person.father_index){
      let father = getApp().globalData.dataBmob[this.data.person.father_index];
      appl.set("father_name",father.username);
      appl.set("father_birthday",father.birthday);
    }
    // getApp().globalData.is_fresh = true;
    Toast.show({
      position:"bottom",
      message:"提交成功"
    })
    appl.save().then(res=>{
      wx.switchTab({
        url: "../index/index",
      }); 
    }).catch(error=>{
      console.log(error);
    })
    // node.set(id,person.objectId);
    // for(let i in event)
  },
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  }
})